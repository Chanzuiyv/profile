# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import re
import chardet
from difflib import SequenceMatcher
import pandas as pd
import xlrd


FIXED_CHARS = {'顾子尧', '江恪', 'LASER', 'MANTA', '林致', '乔殊', '夏予扬', '许向安', '许向宁', '柏闻', '季少一'}


class SubtitleProcessorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("广播剧字幕处理器")
        self.root.geometry("850x680")
        self.root.resizable(True, True)

        self.char_file_path = tk.StringVar()
        self.txt_folder_path = tk.StringVar()
        self.output_folder_path = tk.StringVar()
        self.all_chars = FIXED_CHARS.copy()
        self.filename_char_map = {}
        self.temp_chars = []

        self.create_widgets()

    def create_widgets(self):
        main_frame = ttk.Frame(self.root, padding="15")
        main_frame.pack(fill=tk.BOTH, expand=True)

        title_label = ttk.Label(main_frame, text="广播剧字幕【】→ {} 替换工具",
                                font=("Microsoft YaHei", 14, "bold"))
        title_label.pack(pady=(0, 10))

        char_frame = ttk.LabelFrame(main_frame, text="角色名单表格", padding="8")
        char_frame.pack(fill=tk.X, pady=3)
        ttk.Label(char_frame, text="表格文件：").pack(side=tk.LEFT)
        ttk.Entry(char_frame, textvariable=self.char_file_path, width=45).pack(side=tk.LEFT, padx=5)
        ttk.Button(char_frame, text="选择文件", command=self.select_char_file).pack(side=tk.LEFT)

        folder_frame = ttk.LabelFrame(main_frame, text="TXT字幕文件夹", padding="8")
        folder_frame.pack(fill=tk.X, pady=3)
        ttk.Label(folder_frame, text="输入路径：").pack(side=tk.LEFT)
        ttk.Entry(folder_frame, textvariable=self.txt_folder_path, width=45).pack(side=tk.LEFT, padx=5)
        ttk.Button(folder_frame, text="选择", command=self.select_txt_folder).pack(side=tk.LEFT)

        output_frame = ttk.LabelFrame(main_frame, text="输出文件夹", padding="8")
        output_frame.pack(fill=tk.X, pady=3)
        ttk.Label(output_frame, text="输出路径：").pack(side=tk.LEFT)
        ttk.Entry(output_frame, textvariable=self.output_folder_path, width=45).pack(side=tk.LEFT, padx=5)
        ttk.Button(output_frame, text="选择", command=self.select_output_folder).pack(side=tk.LEFT)

        manual_frame = ttk.LabelFrame(main_frame, text="手动添加角色", padding="8")
        manual_frame.pack(fill=tk.X, pady=3)

        input_frame = tk.Frame(manual_frame)
        input_frame.pack(fill=tk.X)
        ttk.Label(input_frame, text="角色名：").pack(side=tk.LEFT)
        self.char_input = tk.Entry(input_frame, width=20)
        self.char_input.pack(side=tk.LEFT, padx=5)
        tk.Button(input_frame, text="添加", command=self.add_character,
                 bg="#2196F3", fg="white", font=("SimHei", 9), width=8).pack(side=tk.LEFT, padx=2)
        tk.Button(input_frame, text="删除", command=self.delete_character,
                 bg="#FF9800", fg="white", font=("SimHei", 9), width=8).pack(side=tk.LEFT, padx=2)
        tk.Button(input_frame, text="清空", command=self.clear_temp_chars,
                 bg="#9C27B0", fg="white", font=("SimHei", 9), width=8).pack(side=tk.LEFT, padx=2)

        self.temp_chars_listbox = tk.Listbox(manual_frame, height=4)
        self.temp_chars_listbox.pack(fill=tk.X, pady=5)

        info_frame = ttk.LabelFrame(main_frame, text="已加载角色信息", padding="8")
        info_frame.pack(fill=tk.BOTH, pady=3)

        self.info_text = tk.Text(info_frame, height=8, width=80, state=tk.DISABLED)
        self.info_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = ttk.Scrollbar(info_frame, command=self.info_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.info_text.config(yscrollcommand=scrollbar.set)

        btn_frame = tk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=10)

        self.process_btn = tk.Button(btn_frame, text="开始处理", command=self.process_files,
                                     state=tk.DISABLED, bg="#4CAF50", fg="white",
                                     font=("SimHei", 11, "bold"), width=15, height=2)
        self.process_btn.pack(side=tk.LEFT, padx=20)

        tk.Button(btn_frame, text="清空重置", command=self.reset,
                  bg="#f44336", fg="white",
                  font=("SimHei", 11, "bold"), width=15, height=2).pack(side=tk.LEFT, padx=20)

        tk.Button(btn_frame, text="使用说明", command=self.show_help,
                  bg="#2196F3", fg="white",
                  font=("SimHei", 11, "bold"), width=15, height=2).pack(side=tk.LEFT, padx=20)

        self.progress_var = tk.StringVar(value="就绪")
        progress_label = tk.Label(main_frame, textvariable=self.progress_var,
                                  font=("Microsoft YaHei", 9))
        progress_label.pack(pady=5)

    def select_char_file(self):
        filename = filedialog.askopenfilename(
            title="选择角色名单表格",
            filetypes=[("表格文件", "*.xls *.xlsx *.csv"), ("所有文件", "*.*")]
        )
        if filename:
            self.char_file_path.set(filename)
            self.load_char_file(filename)

    def select_txt_folder(self):
        folder = filedialog.askdirectory(title="选择TXT字幕文件夹")
        if folder:
            self.txt_folder_path.set(folder)
            if not self.output_folder_path.get():
                self.output_folder_path.set(folder)
            self.check_ready()

    def select_output_folder(self):
        folder = filedialog.askdirectory(title="选择输出文件夹")
        if folder:
            self.output_folder_path.set(folder)
            self.check_ready()

    def load_char_file(self, filepath):
        try:
            self.all_chars = FIXED_CHARS.copy()
            self.filename_char_map = {}
            ext = os.path.splitext(filepath)[1].lower()

            if ext == '.csv':
                encodings = ['utf-8', 'gbk', 'gb2312', 'gb18030']
                for encoding in encodings:
                    try:
                        df = pd.read_csv(filepath, encoding=encoding)
                        break
                    except:
                        continue
                else:
                    raise Exception("无法识别文件编码")
            elif ext == '.xlsx':
                df = pd.read_excel(filepath, engine='openpyxl')
            elif ext == '.xls':
                df = pd.read_excel(filepath, engine='xlrd')
            else:
                messagebox.showerror("错误", "不支持的文件格式")
                return

            for _, row in df.iterrows():
                if 'temporary_chars' in row and pd.notna(row['temporary_chars']):
                    char_name = str(row['temporary_chars']).strip()
                    if char_name:
                        self.all_chars.add(char_name)
                if 'filename' in row and pd.notna(row['filename']):
                    fname = str(row['filename']).strip()
                    if 'temporary_chars' in row and pd.notna(row['temporary_chars']):
                        char_name = str(row['temporary_chars']).strip()
                        if char_name:
                            if fname not in self.filename_char_map:
                                self.filename_char_map[fname] = set()
                            self.filename_char_map[fname].add(char_name)

            self.update_info_text()
            self.update_temp_chars_listbox()
            self.check_ready()
        except Exception as e:
            messagebox.showerror("加载错误", f"读取表格失败：{str(e)}")

    def update_info_text(self):
        self.info_text.config(state=tk.NORMAL)
        self.info_text.delete(1.0, tk.END)

        self.info_text.insert(tk.END, f"内置常驻角色（11人）：\n")
        for char in sorted(FIXED_CHARS):
            self.info_text.insert(tk.END, f"  · {char}\n")

        if self.temp_chars:
            self.info_text.insert(tk.END, f"\n手动添加的角色：\n")
            for char in sorted(self.temp_chars):
                self.info_text.insert(tk.END, f"  · {char}\n")

        extra_chars = self.all_chars - FIXED_CHARS - set(self.temp_chars)
        if extra_chars:
            self.info_text.insert(tk.END, f"\n外部表格加载的非常驻角色：\n")
            for char in sorted(extra_chars):
                self.info_text.insert(tk.END, f"  · {char}\n")

        if self.filename_char_map:
            self.info_text.insert(tk.END, f"\n剧集对应角色映射：\n")
            for fname, chars in self.filename_char_map.items():
                self.info_text.insert(tk.END, f"  · {fname} → {', '.join(sorted(chars))}\n")

        self.info_text.insert(tk.END, f"\n当前加载角色总数：{len(self.all_chars)} 人")
        self.info_text.config(state=tk.DISABLED)

    def check_ready(self):
        if self.txt_folder_path.get() and self.output_folder_path.get():
            self.process_btn.config(state=tk.NORMAL, bg="#4CAF50")
        else:
            self.process_btn.config(state=tk.DISABLED, bg="#cccccc")

    def reset(self):
        self.char_file_path.set("")
        self.txt_folder_path.set("")
        self.output_folder_path.set("")
        self.all_chars = FIXED_CHARS.copy()
        self.filename_char_map = {}
        self.temp_chars = []
        self.update_info_text()
        self.update_temp_chars_listbox()
        self.progress_var.set("就绪")
        self.check_ready()

    def add_character(self):
        char_name = self.char_input.get().strip()
        if char_name:
            if char_name not in self.temp_chars:
                self.temp_chars.append(char_name)
                self.all_chars.add(char_name)
                self.update_temp_chars_listbox()
                self.update_info_text()
                self.char_input.delete(0, tk.END)
            else:
                messagebox.showinfo("提示", f"角色 '{char_name}' 已存在")
        else:
            messagebox.showwarning("警告", "请输入角色名")

    def delete_character(self):
        selected = self.temp_chars_listbox.curselection()
        if selected:
            for index in reversed(selected):
                char_name = self.temp_chars[index]
                self.temp_chars.pop(index)
                if char_name not in FIXED_CHARS:
                    self.all_chars.discard(char_name)
            self.update_temp_chars_listbox()
            self.update_info_text()
        else:
            messagebox.showwarning("警告", "请先选中要删除的角色")

    def clear_temp_chars(self):
        if self.temp_chars:
            for char in self.temp_chars:
                if char not in FIXED_CHARS:
                    self.all_chars.discard(char)
            self.temp_chars = []
            self.update_temp_chars_listbox()
            self.update_info_text()
            messagebox.showinfo("提示", "已清空所有手动添加的角色")
        else:
            messagebox.showinfo("提示", "没有可清空的角色")

    def update_temp_chars_listbox(self):
        self.temp_chars_listbox.delete(0, tk.END)
        for char in self.temp_chars:
            self.temp_chars_listbox.insert(tk.END, char)

    def detect_encoding(self, filepath):
        with open(filepath, 'rb') as f:
            raw_data = f.read(10000)
        result = chardet.detect(raw_data)
        return result['encoding'] if result['encoding'] in ['utf-8', 'gbk', 'gb2312', 'gb18030'] else 'utf-8'

    def read_file_content(self, filepath):
        encoding = self.detect_encoding(filepath)
        try:
            with open(filepath, 'r', encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            encoding = 'gbk' if encoding == 'utf-8' else 'utf-8'
            with open(filepath, 'r', encoding=encoding) as f:
                return f.read()

    def write_file_content(self, filepath, content):
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
        except Exception as e:
            try:
                with open(filepath, 'w', encoding='gbk') as f:
                    f.write(content)
            except Exception as e2:
                raise Exception(f"写入文件失败: {e2}")

    def fuzzy_match(self, s1, s2, threshold=0.6):
        ratio = SequenceMatcher(None, s1, s2).ratio()
        return ratio >= threshold

    def is_char_name(self, content, txt_filename):
        content = content.strip()
        if '/' in content:
            parts = [p.strip() for p in content.split('/')]
            return all(p in self.all_chars for p in parts)

        if content in self.all_chars:
            return True

        for fname, chars in self.filename_char_map.items():
            if self.fuzzy_match(fname, txt_filename):
                if content in chars:
                    return True

        return False

    def process_bracket_content(self, match, txt_filename):
        content = match.group(1)
        if self.is_char_name(content, txt_filename):
            return match.group(0)
        return '{' + content + '}'

    def process_file(self, filepath):
        txt_filename = os.path.basename(filepath)
        content = self.read_file_content(filepath)

        pattern = re.compile(r'【([^】]+)】')
        new_content = pattern.sub(lambda m: self.process_bracket_content(m, txt_filename), content)

        output_folder = self.output_folder_path.get()
        if not os.path.exists(output_folder):
            os.makedirs(output_folder, exist_ok=True)

        output_filepath = os.path.join(output_folder, txt_filename)
        self.write_file_content(output_filepath, new_content)
        return txt_filename

    def show_help(self):
        help_window = tk.Toplevel(self.root)
        help_window.title("使用说明")
        help_window.geometry("800x600")
        help_window.resizable(True, True)

        help_text = tk.Text(help_window, wrap=tk.WORD, padx=20, pady=20, font=('Microsoft YaHei', 10))
        help_text.pack(fill=tk.BOTH, expand=True)

        scrollbar = ttk.Scrollbar(help_text, command=help_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        help_text.config(yscrollcommand=scrollbar.set)

        help_content = """# 广播剧字幕括号替换工具 - 使用说明

## 工具功能
- 自动将广播剧字幕文件中的【】括号替换为{}括号
- 智能保留角色名的括号不变
- 支持从表格文件加载角色名单
- 支持手动添加临时角色

## 操作步骤

### 1. 启动工具
- 双击下载的exe文件即可启动工具

### 2. 准备角色名单
工具内置了以下角色：
顾子尧、江恪、LASER、MANTA、林致、乔殊、夏予扬、许向安、许向宁、柏闻、季少一

#### 方法1：通过表格文件添加角色
1. 创建Excel表格，包含以下列：
   - temporary_chars：角色名
   - filename（可选）：文件名（用于特定剧集的角色映射）
2. 保存为 .xls、.xlsx 或 .csv 格式
3. 点击"选择文件"按钮加载表格

#### 方法2：手动添加角色
1. 在"手动添加角色"输入框中输入角色名
2. 点击"添加"按钮
3. 角色会显示在下方列表中

### 3. 选择字幕文件夹
1. 点击"TXT字幕文件夹"区域的"选择"按钮
2. 选择存放字幕文件的文件夹
3. 未选择的话默认输出文件夹会自动设置为相同位置

### 4. 选择输出文件夹（可选）
- 如需更改输出位置，点击"输出文件夹"区域的"选择"按钮

### 5. 开始处理
- 点击"开始处理"按钮
- 工具会自动处理所有TXT文件
- 处理完成后会显示结果

## 示例
输入：
【顾子尧】你好
【关门】
【江恪】今天天气真好

输出：
【顾子尧】你好
{关门}
【江恪】今天天气真好

## 注意事项
1. 只处理 .txt 格式文件
2. 处理后的文件保存在输出文件夹
3. 工具会智能识别角色名，保留其括号
4. 遇到编码问题会自动尝试不同编码
5. 处理过程中请勿关闭工具窗口

## 常见问题
- 文件无变化：检查角色名单是否包含字幕中的角色名
- 表格加载失败：确保表格格式正确，列名正确
- 程序无法启动：请确保下载的是完整的exe文件
"""

        help_text.insert(tk.END, help_content)
        help_text.config(state=tk.DISABLED)

    def process_files(self):
        folder = self.txt_folder_path.get()
        if not folder:
            messagebox.showwarning("警告", "请先选择TXT文件夹")
            return

        output_folder = self.output_folder_path.get()
        if not output_folder:
            messagebox.showwarning("警告", "请先选择输出文件夹")
            return

        if not os.path.exists(output_folder):
            os.makedirs(output_folder, exist_ok=True)

        try:
            txt_files = [f for f in os.listdir(folder) if f.endswith('.txt')]
            if not txt_files:
                messagebox.showinfo("提示", "文件夹中没有找到TXT文件")
                return

            self.progress_var.set(f"正在处理 0/{len(txt_files)} ...")
            self.root.update()

            success_count = 0
            skip_count = 0

            for i, txt_file in enumerate(txt_files):
                filepath = os.path.join(folder, txt_file)
                try:
                    self.process_file(filepath)
                    success_count += 1
                except Exception as e:
                    skip_count += 1

                self.progress_var.set(f"正在处理 {i+1}/{len(txt_files)} ...")
                self.root.update()

            self.progress_var.set(f"处理完成！成功: {success_count}, 跳过: {skip_count}")
            messagebox.showinfo("完成", f"处理完成！\n成功: {success_count} 个文件\n跳过: {skip_count} 个文件")

        except Exception as e:
            messagebox.showerror("错误", f"处理过程中出错：{str(e)}")
            self.progress_var.set("处理失败")


def main():
    root = tk.Tk()
    app = SubtitleProcessorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
