"""生成示例广播剧剧集表"""
import openpyxl

wb = openpyxl.Workbook()
ws = wb.active
ws.title = '广播剧剧集'

# 示例数据
dramas = {
    '险象环声': [f'第{i}集' for i in range(1, 67)],
    '碎星鸳羽': [f'第{i}集' for i in range(1, 45)],
    '破云来': [f'第{i}集' for i in range(1, 52)],
}

col = 1
for drama_name, episodes in dramas.items():
    ws.cell(row=1, column=col, value=drama_name)
    for i, ep in enumerate(episodes):
        ws.cell(row=i + 2, column=col, value=ep)
    col += 1

wb.save('广播剧剧集.xlsx')
print('示例文件已生成: 广播剧剧集.xlsx')
