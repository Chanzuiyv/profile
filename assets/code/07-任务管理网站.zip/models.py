from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()


class User(UserMixin, db.Model):
    """用户表"""
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)  # 圈名
    role = db.Column(db.String(20), nullable=False, default='member')  # leader/member/tech
    ip_address = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.now)

    # 关系
    claims = db.relationship('TaskClaim', backref='user', lazy='dynamic')


class Drama(db.Model):
    """广播剧表"""
    __tablename__ = 'dramas'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)  # 广播剧名
    season_number = db.Column(db.Integer)  # 季数
    team = db.Column(db.String(20))  # LASER / MANTA

    episodes = db.relationship('Episode', backref='drama', lazy='dynamic',
                               order_by='Episode.episode_number')


class Episode(db.Model):
    """剧集表"""
    __tablename__ = 'episodes'
    id = db.Column(db.Integer, primary_key=True)
    drama_id = db.Column(db.Integer, db.ForeignKey('dramas.id'), nullable=False)
    episode_name = db.Column(db.String(200), nullable=False)  # 剧集名
    episode_number = db.Column(db.Integer)  # 集数序号

    # 流程进度
    progress = db.relationship('EpisodeProgress', backref='episode', lazy='dynamic')


class Task(db.Model):
    """任务表 (如 险象环声_C1)"""
    __tablename__ = 'tasks'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)  # 任务名
    drama_id = db.Column(db.Integer, db.ForeignKey('dramas.id'), nullable=False)
    round_type = db.Column(db.String(5), nullable=False)  # R1/R2/R3/R4
    ddl = db.Column(db.DateTime)  # 截止日期
    created_at = db.Column(db.DateTime, default=datetime.now)

    drama = db.relationship('Drama', backref='tasks')
    episodes = db.relationship('TaskEpisode', backref='task', lazy='dynamic')
    claims = db.relationship('TaskClaim', backref='task', lazy='dynamic')


class TaskEpisode(db.Model):
    """任务-剧集关联表"""
    __tablename__ = 'task_episodes'
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=False)
    episode_id = db.Column(db.Integer, db.ForeignKey('episodes.id'), nullable=False)

    episode = db.relationship('Episode')


class TaskClaim(db.Model):
    """任务认领表"""
    __tablename__ = 'task_claims'
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    claimed_at = db.Column(db.DateTime, default=datetime.now)

    # R1 进度
    file_submitted = db.Column(db.Boolean, default=False)  # 是否提交文件
    data_cleaned = db.Column(db.Boolean, default=False)  # 数据清洗是否通过
    file_named = db.Column(db.Boolean, default=False)  # 文件规范命名
    submitted_at = db.Column(db.DateTime)  # 提交日期


class EpisodeProgress(db.Model):
    """剧集流程进度表"""
    __tablename__ = 'episode_progress'
    id = db.Column(db.Integer, primary_key=True)
    episode_id = db.Column(db.Integer, db.ForeignKey('episodes.id'), nullable=False)
    round_type = db.Column(db.String(5), nullable=False)  # R1/R2/R3/R4
    status = db.Column(db.String(10), default='pending')  # pending/done


class UploadedFile(db.Model):
    """上传文件表"""
    __tablename__ = 'uploaded_files'
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    original_filename = db.Column(db.String(255))
    stored_filename = db.Column(db.String(255))
    upload_date = db.Column(db.DateTime, default=datetime.now)
    data_cleaned = db.Column(db.Boolean, default=False)
    file_named = db.Column(db.Boolean, default=False)
    version = db.Column(db.String(10))

    user = db.relationship('User')
    task = db.relationship('Task')


class DataCleanError(db.Model):
    """数据清洗错误表"""
    __tablename__ = 'data_clean_errors'
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    episode_name = db.Column(db.String(200))
    error_type = db.Column(db.String(50))  # url_error/chars_error/filename_error/comma_error/count_error
    fixed = db.Column(db.Boolean, default=False)
    round_number = db.Column(db.Integer, default=1)  # 第几轮清洗
