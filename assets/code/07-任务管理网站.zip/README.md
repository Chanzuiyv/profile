# 逐声计划 - 任务管理系统

LASER & MANTA 虚拟男团信息收集工作管理平台

## 项目结构

```
zhusheng-plan/
├── app.py                  # 主应用 (Flask路由 + 业务逻辑)
├── config.py               # 配置文件
├── models.py               # 数据库模型
├── create_sample.py        # 生成示例数据
├── requirements.txt        # Python依赖
├── Procfile                # Render部署配置
├── render.yaml             # Render服务配置
├── templates/              # HTML模板
│   ├── base.html           # 基础布局 (响应式)
│   ├── login.html          # 登录/注册
│   ├── dashboard.html      # 主页
│   ├── leader/             # 组长模板
│   ├── member/             # 组员模板
│   └── tech/               # 技术组模板
├── static/
│   ├── css/style.css       # 样式 (响应式)
│   └── js/main.js          # 前端交互
├── uploads/                # 上传文件存储
└── data/                   # SQLite数据库
```

## 功能概述

### 三种角色
- **组长**: 导入广播剧数据、分配任务(R1-R4)、设置/更改DDL、监控进度
- **组员**: 认领任务、上传文件、数据清洗、文件规范命名、查看进度
- **技术组**: 查看进度、字幕爬取、数据验证

### 四个流程 (R1-R4)
- **R1 信息收集**: 收集广播剧字幕URL、角色信息
- **R2 人工审核**: 审核有其他配音演员的剧集
- **R3 人工复核**: 抽检10%字幕文件
- **R4 兜底任务**: 技术组爬取失败的剧集由内容组人工输入

### 核心特性
- 任务可拆分为子任务 (如 险象环声_C1, _C2, _C3)
- DDL管理及到期提醒 (红色加粗)
- R1流程: 上传 → 数据清洗 → 规范命名, 环环相扣
- 数据清洗自动检测URL、字段、格式等错误
- 响应式设计, 电脑/手机/平板均可使用

---

## 部署方法 (GitHub + Render.com 免费部署)

### 第一步: 安装Git (如未安装)

Mac:
```bash
# 检查是否已安装
git --version
```

### 第二步: 上传代码到GitHub

```bash
# 1. 在GitHub网站上创建新仓库 zhusheng-plan (不要勾选README)
#    访问 https://github.com/new

# 2. 进入项目目录
cd /Users/wuxia/Documents/zhusheng-plan

# 3. 初始化Git仓库
git init
git add .
git commit -m "初始化逐声计划任务管理系统"

# 4. 关联远程仓库 (替换为你的GitHub用户名)
git remote add origin https://github.com/你的用户名/zhusheng-plan.git
git branch -M main
git push -u origin main
```

### 第三步: 在Render.com部署 (免费)

1. **注册**: 访问 https://render.com 用GitHub账号登录
2. **创建服务**:
   - 点击 "New" → "Web Service"
   - 选择 "Build and deploy from a Git repository"
   - 连接GitHub账号, 选择 `zhusheng-plan` 仓库
3. **配置服务**:
   - Name: `zhusheng-plan`
   - Runtime: Python 3
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn app:app`
   - Plan: **Free**
4. **添加环境变量**:
   - Key: `SECRET_KEY`, Value: 随便填一个长字符串 (如 `my-secret-key-abc123`)
5. **添加持久化磁盘** (Free计划也支持):
   - Name: `data`
   - Mount Path: `/opt/render/project/src/data`
   - Size: 1 GB
6. **点击 "Create Web Service"**
7. **等待部署完成**, 大约2-3分钟
8. 部署成功后, 你会得到一个网址:
   `https://zhusheng-plan.onrender.com`

### 以后如何更新

每次你修改代码后:
```bash
git add .
git commit -m "描述你的修改"
git push
```
Render会自动重新部署。

---

## 本地运行测试

```bash
# 1. 安装依赖
pip3 install -r requirements.txt

# 2. 运行
python3 app.py

# 3. 打开浏览器访问 http://localhost:5000
```

---

## 使用说明

### 组长操作流程

1. **注册**: 打开网页, 输入圈名, 选择"组长"角色
2. **导入数据**: 点击"导入广播剧", 上传`广播剧剧集.xlsx`
3. **分配任务**:
   - 选择R1/R2/R3/R4流程
   - 选择要分配的广播剧
   - 设置是否分工(拆分为_C1, _C2...)
   - 设置集数范围和DDL
4. **监控**: 查看组员认领和完成进度
5. **改DDL**: 根据需要灵活调整截止时间

### 组员操作流程

1. **注册**: 打开网页, 输入圈名, 选择"组员"角色
2. **认领任务**: 进入R1/R2/R3/R4认领界面, 选择要做的任务
3. **R1工作流**:
   - 上传收集的文件 (.txt)
   - 进行数据清洗 (自动检查格式)
   - 修正错误 (如有)
   - 规范命名并提交
4. **查看进度**: 随时查看自己的任务进度和DDL

### 技术组操作流程

1. **注册**: 打开网页, 输入圈名, 选择"技术组"角色
2. 查看各流程进度

---

## 多设备访问

部署后, 任何设备通过浏览器访问网址即可:

| 设备 | 访问方式 |
|------|---------|
| 电脑 | 浏览器打开网址 |
| 手机 | 浏览器/微信打开网址 |
| 平板 | 浏览器打开网址 |

系统采用 Bootstrap 5 响应式框架, 自动适配不同屏幕大小。
