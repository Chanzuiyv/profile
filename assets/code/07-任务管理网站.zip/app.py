"""
逐声计划 - 任务管理系统
LASER & MANTA 虚拟男团信息收集工作管理平台
"""
import os
import re
from datetime import datetime, timedelta
from functools import wraps

from flask import (Flask, render_template, request, redirect, url_for,
                   flash, jsonify, send_file, session)
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
import openpyxl
from openpyxl import Workbook

from config import Config
from models import db, User, Drama, Episode, Task, TaskEpisode, TaskClaim
from models import EpisodeProgress, UploadedFile, DataCleanError

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], 'pending'), exist_ok=True)


@app.context_processor
def inject_now():
    """向模板注入当前时间"""
    return {'now': datetime.now()}


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


def role_required(*roles):
    """角色权限装饰器"""
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if current_user.role not in roles:
                flash('您没有权限访问此页面', 'error')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated
    return decorator


def get_user_ddl_warnings(user):
    """获取用户即将到期的DDL"""
    warnings = []
    claims = TaskClaim.query.filter_by(user_id=user.id).all()
    for claim in claims:
        task = claim.task
        if task.ddl and not claim.file_named:
            days_left = (task.ddl - datetime.now()).days
            if days_left <= 4:
                warnings.append({
                    'task_name': task.name,
                    'round': task.round_type,
                    'days_left': days_left,
                    'ddl': task.ddl.strftime('%Y-%m-%d %H:%M')
                })
    return warnings


# ==================== 认证路由 ====================

@app.route('/login', methods=['GET', 'POST'])
def login():
    """用户登录/注册"""
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        confirm = request.form.get('confirm', '').strip()

        if not username:
            flash('请输入您的圈名', 'error')
            return render_template('login.html')

        if not confirm:
            flash('确认后不可更改，请您再输入一遍', 'info')
            session['temp_username'] = username
            return render_template('login.html', step='confirm', temp_username=username)

        if username != confirm:
            flash('检测到输入有出入，请确认您的cn!!', 'error')
            return render_template('login.html', step='input')

        existing = User.query.filter_by(username=username).first()
        if existing:
            login_user(existing)
            flash(f'欢迎{username}回来！', 'success')
            return redirect(url_for('dashboard'))
        else:
            role = request.form.get('role', 'member')
            ip = request.remote_addr
            new_user = User(username=username, role=role, ip_address=ip)
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user)
            flash(f'欢迎{username}加入逐声计划！非常高兴有{username}的加入！', 'success')
            return redirect(url_for('dashboard'))

    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))


# ==================== 主页面路由 ====================

@app.route('/')
@login_required
def dashboard():
    """主界面"""
    warnings = get_user_ddl_warnings(current_user)
    return render_template('dashboard.html', warnings=warnings)


# ==================== 组长路由 ====================

@app.route('/leader')
@login_required
@role_required('leader')
def leader_dashboard():
    """组长控制面板"""
    dramas = Drama.query.all()
    return render_template('leader/dashboard.html', dramas=dramas)


@app.route('/leader/upload_dramas', methods=['GET', 'POST'])
@login_required
@role_required('leader')
def upload_dramas():
    """上传广播剧剧集表"""
    if request.method == 'POST':
        file = request.files.get('file')
        if not file or not file.filename.endswith('.xlsx'):
            flash('请上传xlsx格式的文件', 'error')
            return redirect(url_for('upload_dramas'))

        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        try:
            wb = openpyxl.load_workbook(filepath)
            ws = wb.active

            for col in range(1, ws.max_column + 1):
                drama_name = ws.cell(row=1, column=col).value
                if not drama_name:
                    continue

                drama = Drama.query.filter_by(name=drama_name).first()
                if not drama:
                    season = col  # 列序号对应季数
                    drama = Drama(name=drama_name, season_number=season)
                    db.session.add(drama)
                    db.session.flush()

                for row in range(2, ws.max_row + 1):
                    ep_name = ws.cell(row=row, column=col).value
                    if ep_name:
                        existing = Episode.query.filter_by(
                            drama_id=drama.id, episode_name=str(ep_name)
                        ).first()
                        if not existing:
                            ep = Episode(
                                drama_id=drama.id,
                                episode_name=str(ep_name),
                                episode_number=row - 1
                            )
                            db.session.add(ep)

                            # 初始化流程进度
                            for r in ['R1', 'R2', 'R3', 'R4']:
                                prog = EpisodeProgress(
                                    episode_id=ep.id, round_type=r, status='pending'
                                )
                                db.session.add(prog)

            db.session.commit()
            flash('广播剧剧集表已导入成功！', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'导入失败：{str(e)}', 'error')

        return redirect(url_for('leader_dashboard'))

    return render_template('leader/upload_dramas.html')


@app.route('/leader/assign/<round_type>', methods=['GET', 'POST'])
@login_required
@role_required('leader')
def assign_task(round_type):
    """分配任务 (R1/R2/R3/R4)"""
    if round_type not in ['R1', 'R2', 'R3', 'R4']:
        flash('无效的流程类型', 'error')
        return redirect(url_for('leader_dashboard'))

    dramas = Drama.query.all()

    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'select_dramas':
            selected = request.form.get('selected_dramas', '').strip()
            if selected.lower() == 'all':
                selected_dramas = dramas
            else:
                names = [n.strip() for n in selected.split('/') if n.strip()]
                selected_dramas = Drama.query.filter(Drama.name.in_(names)).all()

            if not selected_dramas:
                flash('未找到指定的广播剧', 'error')
                return redirect(url_for('assign_task', round_type=round_type))

            session['selected_drama_ids'] = [d.id for d in selected_dramas]
            return render_template('leader/assign.html',
                                   round_type=round_type,
                                   step='split',
                                   selected_dramas=selected_dramas)

        elif action == 'set_split':
            drama_id = int(request.form.get('drama_id'))
            split = request.form.get('split', 'no').lower()
            drama = Drama.query.get(drama_id)

            if split == 'no':
                # 不分工 - 整个广播剧作为一个任务
                ddl_str = request.form.get('ddl', '').strip()
                ddl = parse_ddl(ddl_str)
                if not ddl:
                    flash('请设置正确的ddl日期 (格式: YYYY-MM-DD HH:MM)', 'error')
                    return redirect(url_for('assign_task', round_type=round_type))

                task = Task(
                    name=drama.name,
                    drama_id=drama.id,
                    round_type=round_type,
                    ddl=ddl
                )
                db.session.add(task)
                db.session.flush()

                for ep in drama.episodes.all():
                    te = TaskEpisode(task_id=task.id, episode_id=ep.id)
                    db.session.add(te)

                db.session.commit()
                flash(f'任务"{drama.name}"已创建', 'success')

            else:
                # 分工
                num_parts = request.form.get('num_parts', '').strip()
                if not num_parts.isdigit() or int(num_parts) <= 0:
                    flash('请输入有效数字!', 'error')
                    return redirect(url_for('assign_task', round_type=round_type))

                num_parts = int(num_parts)
                session['split_info'] = {
                    'drama_id': drama_id,
                    'num_parts': num_parts,
                    'current_part': 1,
                    'assigned_episodes': set()
                }
                return render_template('leader/assign.html',
                                       round_type=round_type,
                                       step='set_episodes',
                                       drama=drama,
                                       num_parts=num_parts,
                                       current_part=1)

        elif action == 'set_episodes_range':
            split_info = session.get('split_info', {})
            drama_id = split_info['drama_id']
            current_part = split_info['current_part']
            num_parts = split_info['num_parts']
            drama = Drama.query.get(drama_id)
            all_episodes = drama.episodes.all()

            episodes_input = request.form.get('episodes_range', '').strip()
            ddl_str = request.form.get('ddl', '').strip()

            # 解析集数范围
            episode_numbers = parse_episode_range(episodes_input)
            if episode_numbers is None:
                flash('集数格式不正确，请使用 mm-nn 或 mm/nn/... 格式', 'error')
                return redirect(url_for('assign_task', round_type=round_type))

            # 检查重复分配
            already_assigned = split_info.get('assigned_episodes', set())
            overlap = already_assigned & set(episode_numbers)
            if overlap:
                flash(f'请勿重复设置任务! 集数 {overlap} 已被分配', 'error')
                return redirect(url_for('assign_task', round_type=round_type))

            ddl = parse_ddl(ddl_str)
            if not ddl:
                flash('请设置正确的ddl日期 (格式: YYYY-MM-DD HH:MM)', 'error')
                return redirect(url_for('assign_task', round_type=round_type))

            task_name = f"{drama.name}_C{current_part}"
            task = Task(
                name=task_name,
                drama_id=drama.id,
                round_type=round_type,
                ddl=ddl
            )
            db.session.add(task)
            db.session.flush()

            for ep_num in episode_numbers:
                if ep_num <= len(all_episodes):
                    ep = all_episodes[ep_num - 1]
                    te = TaskEpisode(task_id=task.id, episode_id=ep.id)
                    db.session.add(te)

            db.session.commit()

            # 1. 先转 set
            already_assigned = set(already_assigned)

            # 2. 现在可以正常使用 update
            already_assigned.update(episode_numbers)

            # 3. 如果后续还要用 & 运算，最好再转 list
            already_assigned = list(already_assigned)
            split_info['assigned_episodes'] = list(already_assigned)
            split_info['current_part'] = current_part + 1
            session['split_info'] = split_info

            if current_part < num_parts:
                return render_template('leader/assign.html',
                                       round_type=round_type,
                                       step='set_episodes',
                                       drama=drama,
                                       num_parts=num_parts,
                                       current_part=current_part + 1)
            else:
                # 检查是否所有集数都已分配
                total_eps = len(all_episodes)
                if len(already_assigned) < total_eps:
                    flash(f'警告: 第{set(range(1, total_eps+1)) - set(already_assigned)}集未被分配!', 'warning')
                flash(f'{drama.name}的所有子任务已创建完成', 'success')
                session.pop('split_info', None)
                return redirect(url_for('leader_dashboard'))

        return redirect(url_for('leader_dashboard'))

    return render_template('leader/assign.html',
                           round_type=round_type,
                           step='select',
                           dramas=dramas)


@app.route('/leader/change_ddl', methods=['GET', 'POST'])
@login_required
@role_required('leader')
def change_ddl():
    """更改DDL"""
    if request.method == 'POST':
        task_input = request.form.get('task_names', '').strip()

        if task_input.startswith('w '):
            # 指定要更改的任务
            names = [n.strip() for n in task_input[2:].split('/')]
            tasks = Task.query.filter(Task.name.in_(names)).all()
        else:
            names = [n.strip() for n in task_input.split('/')]
            tasks = Task.query.filter(Task.name.in_(names)).all()

        if not tasks:
            flash('未找到指定任务', 'error')
            return redirect(url_for('change_ddl'))

        ddl_str = request.form.get('ddl', '').strip()
        ddl = parse_ddl(ddl_str)
        if not ddl:
            flash('请设置正确的ddl日期 (格式: YYYY-MM-DD HH:MM)', 'error')
            return redirect(url_for('change_ddl'))

        for task in tasks:
            task.ddl = ddl
        db.session.commit()
        flash(f'已更新 {len(tasks)} 个任务的DDL', 'success')
        return redirect(url_for('change_ddl'))

    tasks = Task.query.filter(Task.ddl.isnot(None)).all()
    return render_template('leader/change_ddl.html', tasks=tasks)


@app.route('/leader/monitor')
@login_required
@role_required('leader')
def monitor():
    """监控进度"""
    tasks = Task.query.all()
    task_stats = []
    for task in tasks:
        claims = task.claims.all()
        task_eps = task.episodes.all()
        total = len(task_eps)
        submitted = sum(1 for c in claims if c.file_submitted)
        cleaned = sum(1 for c in claims if c.data_cleaned)
        named = sum(1 for c in claims if c.file_named)

        task_stats.append({
            'task': task,
            'total': total,
            'submitted': submitted,
            'cleaned': cleaned,
            'named': named,
            'progress': int((submitted / total * 100) if total > 0 else 0)
        })

    return render_template('leader/monitor.html', task_stats=task_stats)


@app.route('/leader/generate_excel/<round_type>')
@login_required
@role_required('leader')
def generate_excel(round_type):
    """生成任务分配表Excel"""
    wb = Workbook()
    ws = wb.active
    ws.title = f'{round_type}任务分配表'

    tasks = Task.query.filter_by(round_type=round_type).all()

    col_offset = 1
    for task in tasks:
        # 第一行: 任务名
        ws.cell(row=1, column=col_offset, value=task.name)
        # 第二行: 表头
        ws.cell(row=2, column=col_offset, value='剧集名')
        ws.cell(row=2, column=col_offset + 1, value='ddl')
        ws.cell(row=2, column=col_offset + 2, value='认领人')
        ws.cell(row=2, column=col_offset + 3, value='认领操作时间')

        # 填充剧集
        task_eps = task.episodes.all()
        for i, te in enumerate(task_eps):
            row = i + 3
            ws.cell(row=row, column=col_offset, value=te.episode.episode_name)
            if task.ddl:
                ws.cell(row=row, column=col_offset + 1,
                        value=task.ddl.strftime('%Y-%m-%d %H:%M'))

            # 填充认领人信息
            claim = TaskClaim.query.filter_by(task_id=task.id).first()
            if claim:
                ws.cell(row=row, column=col_offset + 2, value=claim.user.username)
                ws.cell(row=row, column=col_offset + 3,
                        value=claim.claimed_at.strftime('%Y-%m-%d %H:%M'))

        col_offset += 4

    filename = f'{round_type}任务分配表.xlsx'
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    wb.save(filepath)
    return send_file(filepath, as_attachment=True, download_name=filename)


# ==================== 组员路由 ====================

@app.route('/member')
@login_required
@role_required('member')
def member_dashboard():
    """组员控制面板"""
    warnings = get_user_ddl_warnings(current_user)
    my_claims = {
        'R1': TaskClaim.query.filter_by(user_id=current_user.id)
              .join(Task).filter(Task.round_type == 'R1').all(),
        'R2': TaskClaim.query.filter_by(user_id=current_user.id)
              .join(Task).filter(Task.round_type == 'R2').all(),
        'R3': TaskClaim.query.filter_by(user_id=current_user.id)
              .join(Task).filter(Task.round_type == 'R3').all(),
        'R4': TaskClaim.query.filter_by(user_id=current_user.id)
              .join(Task).filter(Task.round_type == 'R4').all(),
    }
    return render_template('member/dashboard.html', warnings=warnings, my_claims=my_claims)


@app.route('/member/claim/<round_type>', methods=['GET', 'POST'])
@login_required
@role_required('member')
def claim_task(round_type):
    """认领任务"""
    if round_type not in ['R1', 'R2', 'R3', 'R4']:
        flash('无效的流程类型', 'error')
        return redirect(url_for('member_dashboard'))

    # 获取可认领的任务(无人认领的)
    available_tasks = Task.query.filter_by(round_type=round_type)\
        .filter(~Task.claims.any()).all()

    if request.method == 'POST':
        num_claim = request.form.get('num_claim', '').strip()

        if not num_claim.isdigit() or int(num_claim) <= 0:
            flash('请输入有效的正整数', 'error')
            return redirect(url_for('claim_task', round_type=round_type))

        num_claim = int(num_claim)
        if num_claim > len(available_tasks):
            flash('当前没有这么多任务可供领取哦', 'error')
            return redirect(url_for('claim_task', round_type=round_type))

        if num_claim > 1:
            confirm = request.form.get('confirm', '').strip()
            if confirm != 'OK':
                return render_template('member/claim.html',
                                       round_type=round_type,
                                       step='multi_confirm',
                                       num_claim=num_claim,
                                       available_tasks=available_tasks)

        # 处理认领
        task_names = request.form.getlist('task_names')
        for task_name in task_names:
            task = Task.query.filter_by(name=task_name, round_type=round_type).first()
            if not task:
                flash(f'任务"{task_name}"不存在', 'error')
                continue

            # 检查是否已认领
            existing = TaskClaim.query.filter_by(
                task_id=task.id, user_id=current_user.id
            ).first()
            if existing:
                flash(f'您已领取过{task.name}，请勿重复领取!!!', 'error')
                continue

            # 检查是否被他人认领
            claimed = TaskClaim.query.filter_by(task_id=task.id).first()
            if claimed:
                flash(f'{task.name}已被{claimed.user.username}认领，请选择其他任务哦!', 'error')
                continue

            claim = TaskClaim(
                task_id=task.id,
                user_id=current_user.id,
                claimed_at=datetime.now()
            )
            db.session.add(claim)

        db.session.commit()
        flash('任务认领成功！', 'success')
        return redirect(url_for('member_dashboard'))

    return render_template('member/claim.html',
                           round_type=round_type,
                           step='select',
                           available_tasks=available_tasks)


@app.route('/member/progress/<round_type>')
@login_required
@role_required('member')
def member_progress(round_type):
    """查看进度及DDL"""
    claims = TaskClaim.query.filter_by(user_id=current_user.id)\
        .join(Task).filter(Task.round_type == round_type).all()

    progress_data = []
    for claim in claims:
        task = claim.task
        task_eps = task.episodes.all()
        days_left = None
        if task.ddl:
            days_left = (task.ddl - datetime.now()).days

        progress_data.append({
            'task': task,
            'claim': claim,
            'total_episodes': len(task_eps),
            'days_left': days_left,
            'file_submitted': claim.file_submitted,
            'data_cleaned': claim.data_cleaned,
            'file_named': claim.file_named,
        })

    return render_template('member/progress.html',
                           round_type=round_type,
                           progress_data=progress_data)


@app.route('/member/upload/<int:task_id>', methods=['GET', 'POST'])
@login_required
@role_required('member')
def upload_file(task_id):
    """上传文件 (R1)"""
    task = Task.query.get_or_404(task_id)
    claim = TaskClaim.query.filter_by(task_id=task_id, user_id=current_user.id).first_or_404()

    if request.method == 'POST':
        file = request.files.get('file')
        if not file:
            flash('请选择文件', 'error')
            return redirect(url_for('upload_file', task_id=task_id))

        filename = secure_filename(file.filename)
        user_dir = os.path.join(app.config['UPLOAD_FOLDER'],
                                f'{current_user.id}_R1_pending')
        os.makedirs(user_dir, exist_ok=True)
        filepath = os.path.join(user_dir, filename)
        file.save(filepath)

        # 记录上传
        uploaded = UploadedFile(
            task_id=task_id,
            user_id=current_user.id,
            original_filename=file.filename,
            stored_filename=filepath,
            upload_date=datetime.now()
        )
        db.session.add(uploaded)

        claim.file_submitted = True
        db.session.commit()

        flash(f'文件"{filename}"上传成功！', 'success')
        return redirect(url_for('upload_file', task_id=task_id))

    return render_template('member/upload.html', task=task, claim=claim)


@app.route('/member/data_clean/<int:task_id>', methods=['GET', 'POST'])
@login_required
@role_required('member')
def data_clean(task_id):
    """数据清洗 (R1)"""
    task = Task.query.get_or_404(task_id)
    claim = TaskClaim.query.filter_by(task_id=task_id, user_id=current_user.id).first_or_404()

    if not claim.file_submitted:
        flash('请先上传文件', 'error')
        return redirect(url_for('upload_file', task_id=task_id))

    if request.method == 'POST':
        # 执行数据清洗
        user_dir = os.path.join(app.config['UPLOAD_FOLDER'],
                                f'{current_user.id}_R1_pending')
        errors = perform_data_cleaning(user_dir, task, current_user)

        if not errors:
            claim.data_cleaned = True
            db.session.commit()
            flash('恭喜! 所有剧集已通过数据清洗! 请对文件进行规范命名', 'success')
            return redirect(url_for('file_naming', task_id=task_id))
        else:
            flash(f'发现 {len(errors)} 处错误，请查看错误报告并修正', 'warning')
            return redirect(url_for('data_clean', task_id=task_id))

    # 显示当前错误状态
    errors = DataCleanError.query.filter_by(
        task_id=task_id, user_id=current_user.id, fixed=False
    ).all()

    return render_template('member/data_clean.html', task=task, claim=claim, errors=errors)


@app.route('/member/file_naming/<int:task_id>', methods=['GET', 'POST'])
@login_required
@role_required('member')
def file_naming(task_id):
    """文件规范命名"""
    task = Task.query.get_or_404(task_id)
    claim = TaskClaim.query.filter_by(task_id=task_id, user_id=current_user.id).first_or_404()

    if not claim.data_cleaned:
        flash('请先完成数据清洗', 'error')
        return redirect(url_for('data_clean', task_id=task_id))

    if request.method == 'POST':
        version = request.form.get('version', '1').strip()
        user_dir = os.path.join(app.config['UPLOAD_FOLDER'],
                                f'{current_user.id}_R1_pending')

        if os.path.exists(user_dir):
            date_str = datetime.now().strftime('%Y%m%d')
            for f in os.listdir(user_dir):
                old_path = os.path.join(user_dir, f)
                if os.path.isfile(old_path):
                    ext = os.path.splitext(f)[1]
                    new_name = f"R1{task.name}_{current_user.username}_{date_str}_v{version}{ext}"
                    new_path = os.path.join(user_dir, new_name)
                    os.rename(old_path, new_path)

                    # 移到组长待处理文件夹
                    leader_dir = os.path.join(app.config['UPLOAD_FOLDER'], 'R1_pending')
                    os.makedirs(leader_dir, exist_ok=True)
                    import shutil
                    shutil.move(new_path, os.path.join(leader_dir, new_name))

        claim.file_named = True
        claim.submitted_at = datetime.now()
        db.session.commit()

        flash(f'{task.name}已完成! 非常感谢您!', 'success')
        return redirect(url_for('member_dashboard'))

    return render_template('member/file_naming.html', task=task, claim=claim)


# ==================== 技术组路由 ====================

@app.route('/tech')
@login_required
@role_required('tech')
def tech_dashboard():
    """技术组控制面板"""
    return render_template('tech/dashboard.html')


# ==================== 辅助函数 ====================

def parse_ddl(ddl_str):
    """解析DDL日期字符串"""
    if not ddl_str:
        return None
    try:
        return datetime.strptime(ddl_str.strip(), '%Y-%m-%d %H:%M')
    except ValueError:
        try:
            return datetime.strptime(ddl_str.strip(), '%y-%m-%d %H:%M')
        except ValueError:
            return None


def parse_episode_range(range_str):
    """解析集数范围
    支持格式: 1-20 (连续), 1/3/7 (分散), 1-20 23/27 (混合)
    """
    if not range_str:
        return None

    result = set()
    parts = range_str.strip().split()

    for part in parts:
        if '/' in part:
            for num in part.split('/'):
                num = num.strip()
                if num.isdigit():
                    result.add(int(num))
                else:
                    return None
        elif '-' in part:
            nums = part.split('-')
            if len(nums) == 2 and nums[0].isdigit() and nums[1].isdigit():
                start, end = int(nums[0]), int(nums[1])
                if start > end:
                    return None
                result.update(range(start, end + 1))
            else:
                return None
        elif part.isdigit():
            result.add(int(part))
        else:
            return None

    return sorted(result) if result else None


def perform_data_cleaning(user_dir, task, user):
    """执行数据清洗"""
    errors = []
    if not os.path.exists(user_dir):
        return errors

    # 获取广播剧季度信息判断URL位数
    drama = task.drama
    is_season_1_to_5 = drama.season_number and drama.season_number <= 5

    for filename in os.listdir(user_dir):
        filepath = os.path.join(user_dir, filename)
        if not os.path.isfile(filepath):
            continue

        with open(filepath, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        if not lines:
            continue

        task_eps = task.episodes.all()
        expected_count = len(task_eps)
        actual_count = len(lines)  # 假设第一行是表头

        for i, line in enumerate(lines):
            line = line.strip()
            if not line:
                continue

            # 替换中文逗号
            line = line.replace('，', ',')
            parts = line.split(',')

            ep_name = parts[0] if parts else f'第{i+1}行'

            # 规则5: 检查逗号数量 (应该3个英文逗号 = 4个字段)
            if len(parts) != 4:
                errors.append({
                    'episode': ep_name,
                    'type': 'comma_error',
                    'detail': f'应为4个字段，实际{len(parts)}个'
                })
                DataCleanError(
                    task_id=task.id, user_id=user.id,
                    episode_name=ep_name, error_type='comma_error'
                ).save_or_update(db)

            # 规则1: 检查URL (soundid列)
            if len(parts) >= 2:
                url = parts[1].strip()
                expected_len = 7 if is_season_1_to_5 else 8
                if not url or not url.isdigit() or len(url) != expected_len:
                    errors.append({
                        'episode': ep_name,
                        'type': 'url_error',
                        'detail': f'URL应为{expected_len}位纯数字'
                    })

            # 规则2: 检查other_chars列
            if len(parts) >= 3:
                chars = parts[2].strip()
                if not chars or chars not in ['有', '没有']:
                    errors.append({
                        'episode': ep_name,
                        'type': 'chars_error',
                        'detail': 'other_chars必须为"有"或"没有"'
                    })

            # 规则3: 检查filename列
            if len(parts) >= 4:
                fname = parts[3].strip()
                if not fname:
                    errors.append({
                        'episode': ep_name,
                        'type': 'filename_error',
                        'detail': 'filename不能为空'
                    })

        # 规则4: 检查行数
        if actual_count != expected_count:
            errors.append({
                'episode': '数量不匹配',
                'type': 'count_error',
                'detail': f'应为{expected_count}行，实际{actual_count}行'
            })

    # 生成错误报告Excel
    if errors:
        generate_error_report(user, task, errors)

    return errors


def generate_error_report(user, task, errors):
    """生成错误修正表"""
    wb = Workbook()
    ws = wb.active
    ws.title = '错误修正表'

    # 表头
    headers = ['URL错误', '', 'other_chars错误', '', 'filename错误', '',
                '逗号错误', '', '数量不匹配错误', '']
    for i, h in enumerate(headers):
        ws.cell(row=1, column=i + 1, value=h)

    # 按错误类型分组
    error_groups = {
        'url_error': [], 'chars_error': [], 'filename_error': [],
        'comma_error': [], 'count_error': []
    }
    for e in errors:
        error_groups.get(e['type'], []).append(e['episode'])

    for col_idx, (key, eps) in enumerate([
        ('url_error', 1), ('chars_error', 3), ('filename_error', 5),
        ('comma_error', 7), ('count_error', 9)
    ]):
        episodes = error_groups.get(list(error_groups.keys())[
            [1, 3, 5, 7, 9].index(col_idx + 1)
        ], [])
        for row_idx, ep in enumerate(episodes):
            ws.cell(row=row_idx + 2, column=col_idx + 1, value=ep)

    filename = f'{user.username}R1错误修正表.xlsx'
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    wb.save(filepath)


# ==================== API路由 ====================

@app.route('/api/tasks/<round_type>')
@login_required
def api_tasks(round_type):
    """获取任务列表API"""
    tasks = Task.query.filter_by(round_type=round_type).all()
    result = []
    for t in tasks:
        claimed_by = None
        claim = TaskClaim.query.filter_by(task_id=t.id).first()
        if claim:
            claimed_by = claim.user.username

        result.append({
            'id': t.id,
            'name': t.name,
            'ddl': t.ddl.strftime('%Y-%m-%d %H:%M') if t.ddl else None,
            'claimed_by': claimed_by,
            'episode_count': t.episodes.count()
        })
    return jsonify(result)


@app.route('/api/progress/<int:task_id>')
@login_required
def api_progress(task_id):
    """获取任务进度API"""
    claim = TaskClaim.query.filter_by(
        task_id=task_id, user_id=current_user.id
    ).first()
    if not claim:
        return jsonify({'error': '未认领此任务'}), 403

    return jsonify({
        'file_submitted': claim.file_submitted,
        'data_cleaned': claim.data_cleaned,
        'file_named': claim.file_named,
        'submitted_at': claim.submitted_at.strftime('%Y-%m-%d') if claim.submitted_at else None
    })


# ==================== 初始化 ====================

def init_db():
    """初始化数据库"""
    with app.app_context():
        db.create_all()

        # 创建默认管理员（用于首次部署）
        if not User.query.filter_by(role='leader').first():
            leader = User(username='组长', role='leader', ip_address='admin')
            db.session.add(leader)
            db.session.commit()
            print('已创建默认组长账号: 组长')


if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
