// 逐声计划 - 前端交互脚本

document.addEventListener('DOMContentLoaded', function() {
    // 自动关闭提示消息
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            bsAlert.close();
        }, 5000);
    });

    // 文件上传拖拽
    const uploadZone = document.querySelector('.upload-zone');
    if (uploadZone) {
        const fileInput = uploadZone.querySelector('input[type="file"]');

        uploadZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadZone.classList.add('bg-light');
        });

        uploadZone.addEventListener('dragleave', () => {
            uploadZone.classList.remove('bg-light');
        });

        uploadZone.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadZone.classList.remove('bg-light');
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
            }
        });
    }

    // 任务认领 - 动态显示选择框
    const numInput = document.querySelector('input[name="num_claim"]');
    if (numInput) {
        numInput.addEventListener('input', function() {
            const num = parseInt(this.value) || 0;
            const maxTasks = parseInt(this.max) || 1;

            if (num > maxTasks) {
                this.value = maxTasks;
            }
        });
    }

    // DDL格式验证
    const ddlInputs = document.querySelectorAll('input[name="ddl"]');
    ddlInputs.forEach(input => {
        input.addEventListener('blur', function() {
            const val = this.value.trim();
            if (val && !isValidDateTime(val)) {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    });

    // 集数范围格式验证
    const episodeInputs = document.querySelectorAll('input[name="episodes_range"]');
    episodeInputs.forEach(input => {
        input.addEventListener('blur', function() {
            const val = this.value.trim();
            if (val && !isValidEpisodeRange(val)) {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    });
});

/**
 * 验证日期时间格式 (YYYY-MM-DD HH:MM 或 YY-MM-DD HH:MM)
 */
function isValidDateTime(str) {
    const patterns = [
        /^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}$/,
        /^\d{2}-\d{2}-\d{2}\s\d{2}:\d{2}$/
    ];
    return patterns.some(p => p.test(str));
}

/**
 * 验证集数范围格式
 */
function isValidEpisodeRange(str) {
    const parts = str.split(/\s+/);
    for (const part of parts) {
        if (part.includes('-')) {
            const nums = part.split('-');
            if (nums.length !== 2 || !nums.every(n => /^\d+$/.test(n))) return false;
        } else if (part.includes('/')) {
            const nums = part.split('/');
            if (!nums.every(n => /^\d+$/.test(n))) return false;
        } else {
            if (!/^\d+$/.test(part)) return false;
        }
    }
    return true;
}
