import os
import re
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from collections import defaultdict
import pandas as pd
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# ===================== 【全局配置】 =====================
# 默认角色列表
DEFAULT_ROLES = [
    "林致", "顾子尧", "季少一", "江恪",
    "许向安", "许向宁", "乔殊", "柏闻", "夏予扬",'大乔','滚爷'
]

# 默认剧集顺序
DEFAULT_DRAMA_ORDER = [
    "LASER出道日",
    "险象环声",
    "WE FOUR",
    "FINE DAY",
    "一起再出发",
    "名利场",
    "NEW DAYS"
]

# 默认预设称呼（作为初始值）
DEFAULT_PRESET_NICKNAMES = {
    "林致": ["吱吱","喵～","小林同志","林","林哥","林致","林致哥","致致"],
    "顾子尧": ["喵～","子尧","子尧哥","酷哥","队长","顾大队长","顾子尧","顾队","顾队长"],
    "季少一": ["一一","喵","季公主","季前辈","季少","季少一","季少一先生","季少一前辈","季老师","小狐狸","少一","少一哥","李多一","李少一","混蛋","老季"],
    "江恪": ["克制哥","喵","小江江","恪宝","恪恪","江大美女","江大聪明","江大门面","江恪","江恪先生","江恪哥","江恪大宝贝","江江宝贝","江老师","阿恪"],
    "许向安": ["向安","哥","哥哥","喵","安安","安安小朋友","安宝","小孩儿","小安安","许向安"],
    "许向宁": ["向宁","哥","喵","宁宁","宁宁小朋友","宁宝","小坏蛋","小孩儿","小宁宁","弟弟","臭弟弟","许向宁"],
    "乔殊": ["乔殊","乔殊哥","乔殊哥哥","乔殊小同志","哥","喵～～","小乔","小乔哥","小帅哥","殊殊","殊殊子","殊殊小宝贝"],
    "柏闻": ["喵","大少爷","好队长","少爷","我亲爱的队长","柏前辈","柏大少爷","柏大帅哥","柏大队长","柏老师","柏闻","柏闻先生","柏闻前辈","柏队","老狐狸","队长"],
    "夏予扬": ["喵！","夏予扬","夏予扬小同志","夏佩奇","夏大厨","夏太狼","夏扬扬","夏甜甜","夏老弟","小夏同志","小羊","小羊小朋友","扬扬"],
    '大乔':["大乔","大乔宝贝","女明星","小白楼恶霸","小美女"],
    '滚爷':["喵！@#%!","滚大爷","滚爷","许滚滚"]
}

# ===================== 【工具函数】 =====================
def parse_episode(filename):
    match = re.findall(r'\d+', filename)
    return int(match[-1]) if match else 1

def clean_role_name(role_str):
    role_str = role_str.strip()
    role_str = role_str.strip("[]【】")
    return role_str

def safe_filename(name):
    invalid = ['<','>',':','"','/','\\','|','?','*','!','@','#','$','%','^','&','~']
    for c in invalid:
        name = name.replace(c, '')
    return name.strip()

# ===================== 【称呼汇总核心功能】 =====================
class NicknameAnalyzer:
    def __init__(self, root_folder, output_excel, roles, drama_order, preset_nicknames):
        self.root_folder = root_folder
        self.output_excel = output_excel
        self.roles = roles
        self.drama_order = drama_order
        self.preset_nicknames = preset_nicknames
        
        # 全局数据结构
        self.main_dict = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
        self.suspected_nicknames = []
        self.error_report = []
        self.all_lines = []

    def load_all_subtitles(self, progress_callback=None):
        if progress_callback:
            progress_callback("开始读取所有字幕文件...")
        
        total_files = 0
        processed_files = 0
        
        # 先统计总文件数
        for drama in self.drama_order:
            folder_path = os.path.join(self.root_folder, drama)
            if os.path.exists(folder_path):
                for filename in os.listdir(folder_path):
                    if filename.endswith(".txt"):
                        total_files += 1

        for drama in self.drama_order:
            folder_path = os.path.join(self.root_folder, drama)
            if not os.path.exists(folder_path):
                if progress_callback:
                    progress_callback(f"跳过不存在的文件夹：{drama}")
                continue
            
            file_count = 0
            for filename in os.listdir(folder_path):
                if not filename.endswith(".txt"):
                    continue
                
                file_path = os.path.join(folder_path, filename)
                episode = parse_episode(filename)
                current_speaker = None
                
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        for line in f:
                            line = line.strip()
                            if not line: continue
                            if line.startswith(("[", "【")) and (line.endswith("]") or line.endswith("】")):
                                current_speaker = clean_role_name(line)
                            else:
                                if current_speaker:
                                    self.all_lines.append((current_speaker, line, drama, episode))
                    
                    file_count += 1
                    processed_files += 1
                    if progress_callback and total_files > 0:
                        progress = int(processed_files / total_files * 100)
                        progress_callback(f"读取中：{drama} - {filename} ({processed_files}/{total_files} - {progress}%)")
                        
                except Exception as e:
                    if progress_callback:
                        progress_callback(f"读取失败 {filename}：{str(e)}")
            
            if progress_callback:
                progress_callback(f"{drama}：成功读取 {file_count} 个文件")
        
        if progress_callback:
            progress_callback(f"总共加载台词：{len(self.all_lines)} 句")

    def match_preset_nicknames(self, progress_callback=None):
        if progress_callback:
            progress_callback("开始匹配预设称呼...")
        
        total_lines = len(self.all_lines)
        for idx, (speaker, line, drama, ep) in enumerate(self.all_lines):
            for target_role, nick_list in self.preset_nicknames.items():
                if speaker == target_role: continue
                for nick in nick_list:
                    if nick in line:
                        record_key = f"{drama}_第{ep}集"
                        if record_key not in self.main_dict[speaker][target_role][nick]:
                            self.main_dict[speaker][target_role][nick].append(record_key)
            
            if progress_callback and idx % 100 == 0:
                progress = int(idx / total_lines * 100)
                progress_callback(f"匹配称呼：{idx}/{total_lines} ({progress}%)")

    def match_name_fragments(self, progress_callback=None):
        if progress_callback:
            progress_callback("开始拆字检索疑似称呼...")
        
        fragment_dict = defaultdict(list)
        main_roles = [r for r in self.roles if r not in ['大乔','滚爷']]
        
        for role in main_roles:
            chars = list(role)
            for i in range(len(chars)-1):
                fragment_dict[role].append("".join(chars[i:i+2]))
            if len(chars)>=3:
                for i in range(len(chars)-2):
                    fragment_dict[role].append("".join(chars[i:i+3]))
        
        total_lines = len(self.all_lines)
        for idx, (speaker, line, drama, ep) in enumerate(self.all_lines):
            for role, fragments in fragment_dict.items():
                if speaker == role: continue
                for frag in fragments:
                    if frag in line and frag not in self.preset_nicknames.get(role, []):
                        self.suspected_nicknames.append({
                            "剧集": f"{drama}_第{ep}集",
                            "说话人": speaker,
                            "疑似片段": frag,
                            "可能角色": role
                        })
            
            if progress_callback and idx % 100 == 0:
                progress = int(idx / total_lines * 100)
                progress_callback(f"拆字检索：{idx}/{total_lines} ({progress}%)")

    def check_completeness(self, progress_callback=None):
        if progress_callback:
            progress_callback("生成异常报告...")
        
        for A in self.roles:
            for B in self.roles:
                if A == B: continue
                if not self.main_dict[A][B]:
                    self.error_report.append({
                        "异常类型": "缺失称呼",
                        "内容": f"{A} → {B} 无任何称呼记录",
                        "备注": ""
                    })

    def build_statistics(self):
        stat_list = []
        for speaker, targets in self.main_dict.items():
            for target, nicknames in targets.items():
                total_count = sum(len(eps) for eps in nicknames.values())
                for nick, eps in nicknames.items():
                    cnt = len(eps)
                    ratio = round(cnt / total_count * 100, 2) if total_count > 0 else 0
                    stat_list.append({
                        "说话角色": speaker,
                        "被称呼角色": target,
                        "称呼": nick,
                        "出现次数": cnt,
                        "占比(%)": ratio
                    })
        return stat_list

    def build_cross_table(self):
        cross_data = {}
        for speaker in self.roles:
            row = {}
            for target in self.roles:
                if speaker == target:
                    row[target] = ""
                    continue
                nicks = list(self.main_dict[speaker][target].keys())
                row[target] = "、".join(nicks) if nicks else ""
            cross_data[speaker] = row
        df_cross = pd.DataFrame(cross_data).T
        df_cross.index.name = "称呼人\\被称呼人"
        return df_cross

    def build_never_use_table(self):
        never_use = []
        for target_role, nick_list in self.preset_nicknames.items():
            for nick in nick_list:
                never_users = []
                for speaker in self.roles:
                    if speaker == target_role: continue
                    if nick not in self.main_dict[speaker][target_role]:
                        never_users.append(speaker)
                never_use.append({
                    "被称呼角色": target_role,
                    "称呼": nick,
                    "不会这么喊的角色": "、".join(never_users) if never_users else "无"
                })
        return pd.DataFrame(never_use)

    def build_trend_table(self):
        trend = []
        for speaker, targets in self.main_dict.items():
            for target, nicks in targets.items():
                for nick, eps in nicks.items():
                    for drama_name in self.drama_order:
                        cnt = sum(1 for ep_key in eps if drama_name in ep_key)
                        trend.append({
                            "说话人": speaker,
                            "被称呼人": target,
                            "称呼": nick,
                            "季数/时间": drama_name,
                            "本季出现次数": cnt
                        })
        return pd.DataFrame(trend)

    def export_excel(self, progress_callback=None):
        if progress_callback:
            progress_callback("开始生成Excel文件...")
        
        # 构建明细数据
        detail_list = []
        for speaker, targets in self.main_dict.items():
            for target, nicknames in targets.items():
                for nick, keys in nicknames.items():
                    detail_list.append({
                        "说话角色": speaker,
                        "被称呼角色": target,
                        "称呼": nick,
                        "出现剧集": "、".join(sorted(keys))
                    })

        # 生成各类统计表格
        stat_list = self.build_statistics()
        df_cross = self.build_cross_table()
        df_never = self.build_never_use_table()
        df_trend = self.build_trend_table()

        # 导出Excel
        try:
            with pd.ExcelWriter(self.output_excel, engine="openpyxl") as writer:
                pd.DataFrame(detail_list).to_excel(writer, sheet_name="1_称呼总明细", index=False)
                pd.DataFrame(stat_list).to_excel(writer, sheet_name="2_占比统计", index=False)
                pd.DataFrame(self.error_report).to_excel(writer, sheet_name="3_异常报告", index=False)
                df_cross.to_excel(writer, sheet_name="4_十字称呼汇总", index=True)
                pd.DataFrame(df_never).to_excel(writer, sheet_name="5_不会喊的称呼", index=False)
                pd.DataFrame(self.suspected_nicknames).to_excel(writer, sheet_name="6_拆字疑似称呼", index=False)
                df_trend.to_excel(writer, sheet_name="7_称呼时间趋势", index=False)
            
            if progress_callback:
                progress_callback(f"Excel文件已保存至：{self.output_excel}")
            return True
        except Exception as e:
            if progress_callback:
                progress_callback(f"Excel导出失败：{str(e)}")
            return False

    def run_analysis(self, progress_callback=None):
        """执行完整的称呼分析流程"""
        try:
            # 1. 加载字幕
            self.load_all_subtitles(progress_callback)
            if not self.all_lines:
                if progress_callback:
                    progress_callback("错误：未加载到任何台词数据！")
                return False
            
            # 2. 匹配预设称呼
            self.match_preset_nicknames(progress_callback)
            
            # 3. 拆字检索
            self.match_name_fragments(progress_callback)
            
            # 4. 完整性检查
            self.check_completeness(progress_callback)
            
            # 5. 导出Excel
            export_success = self.export_excel(progress_callback)
            
            if export_success and progress_callback:
                progress_callback("称呼分析完成！")
            return export_success
        except Exception as e:
            if progress_callback:
                progress_callback(f"分析过程出错：{str(e)}")
            return False

# ===================== 【画图工具核心功能】 =====================
class PlotGenerator:
    def __init__(self, excel_path, plot_folder, drama_order):
        self.excel_path = excel_path
        self.plot_folder = plot_folder
        self.drama_order = drama_order
        self.df_trend = None
        
        # 创建保存文件夹
        os.makedirs(self.plot_folder, exist_ok=True)

    def load_trend_data(self, progress_callback=None):
        """加载趋势数据"""
        try:
            if progress_callback:
                progress_callback("正在读取Excel中的趋势数据...")
            
            self.df_trend = pd.read_excel(self.excel_path, sheet_name="7_称呼时间趋势")
            
            if progress_callback:
                progress_callback("趋势数据读取完成！")
            return True
        except Exception as e:
            if progress_callback:
                progress_callback(f"读取趋势数据失败：{str(e)}")
            return False

    def generate_plot(self, speaker, target, nicknames, progress_callback=None):
        """生成指定的趋势图"""
        if self.df_trend is None:
            if not self.load_trend_data(progress_callback):
                return False
        
        # 筛选数据
        df_filter = self.df_trend[
            (self.df_trend["说话人"] == speaker) &
            (self.df_trend["被称呼人"] == target) &
            (self.df_trend["称呼"].isin(nicknames))
        ]

        if df_filter.empty:
            if progress_callback:
                progress_callback("没有找到匹配的数据，请检查输入的角色和称呼是否正确")
            return False

        try:
            # 设置中文字体
            plt.rcParams["font.sans-serif"] = ["SimHei"]
            plt.rcParams["axes.unicode_minus"] = False
            
            # 创建图表
            fig, ax = plt.subplots(figsize=(12, 6))
            
            # 绘制每条称呼的趋势线
            for nick in nicknames:
                sub = df_filter[df_filter["称呼"] == nick].copy()
                sub["排序"] = sub["季数/时间"].map(self.drama_order.index)
                sub = sub.sort_values("排序")
                
                x = sub["排序"].tolist()
                y = sub["本季出现次数"].tolist()
                ax.plot(x, y, marker='o', linewidth=2, label=nick, markersize=6)

            # 设置X轴
            ax.set_xticks(range(len(self.drama_order)))
            ax.set_xticklabels(self.drama_order, rotation=30, ha='right')
            
            # 设置Y轴
            max_val = df_filter["本季出现次数"].max()
            y_upper = max_val + 2 if max_val > 0 else 5
            ax.set_ylim(0, y_upper)
            ax.yaxis.set_major_locator(plt.MaxNLocator(integer=True))
            
            # 设置标题和标签
            ax.set_title(f"{speaker} → {target} 称呼使用趋势", fontsize=16, pad=20)
            ax.set_ylabel("出现次数", fontsize=12)
            ax.set_xlabel("剧集", fontsize=12)
            
            # 添加图例和网格
            ax.legend(loc='upper right', frameon=True, shadow=True)
            ax.grid(True, alpha=0.3)
            
            # 调整布局并保存
            plt.tight_layout()
            
            # 生成安全的文件名
            safe_spk = safe_filename(speaker)
            safe_tgt = safe_filename(target)
            nick_str = "_".join([safe_filename(n) for n in nicknames])
            fname = f"{safe_spk}→{safe_tgt}_{nick_str}_趋势图.png"
            save_path = os.path.join(self.plot_folder, fname)
            
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            if progress_callback:
                progress_callback(f"趋势图已保存至：{save_path}")
            return True
        except Exception as e:
            if progress_callback:
                progress_callback(f"生成图表失败：{str(e)}")
            return False

# ===================== 【图形界面】 =====================
class MainApplication:
    def __init__(self, root):
        self.root = root
        self.root.title("MANTA称呼分析工具 v1.0")
        self.root.geometry("900x700")
        self.root.resizable(True, True)
        
        # 初始化配置
        self.current_roles = DEFAULT_ROLES.copy()
        self.current_drama_order = DEFAULT_DRAMA_ORDER.copy()
        self.current_preset_nicknames = DEFAULT_PRESET_NICKNAMES.copy()
        
        # 创建主界面
        self.create_main_interface()

    def create_main_interface(self):
        """创建主界面"""
        # 主面板
        main_notebook = ttk.Notebook(self.root)
        main_notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 1. 功能选择面板
        func_frame = ttk.Frame(main_notebook)
        main_notebook.add(func_frame, text="功能选择")
        self.create_function_panel(func_frame)
        
        # 2. 配置面板
        config_frame = ttk.Frame(main_notebook)
        main_notebook.add(config_frame, text="参数配置")
        self.create_config_panel(config_frame)
        
        # 3. 日志面板
        log_frame = ttk.Frame(main_notebook)
        main_notebook.add(log_frame, text="运行日志")
        self.create_log_panel(log_frame)

    def create_function_panel(self, parent):
        """创建功能选择面板"""
        # 标题
        title_label = ttk.Label(parent, text="功能选择", font=("黑体", 14))
        title_label.pack(pady=10)
        
        # 称呼汇总功能区
        analysis_frame = ttk.LabelFrame(parent, text="称呼汇总分析", padding=10)
        analysis_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # 路径选择
        ttk.Label(analysis_frame, text="根文件夹（包含各剧集文件夹）：").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.root_folder_var = tk.StringVar()
        ttk.Entry(analysis_frame, textvariable=self.root_folder_var, width=50).grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(analysis_frame, text="浏览", command=lambda: self.select_folder(self.root_folder_var)).grid(row=0, column=2, pady=5)
        
        ttk.Label(analysis_frame, text="输出Excel路径：").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.output_excel_var = tk.StringVar()
        self.output_excel_var.set(os.path.join(os.getcwd(), "称呼分析结果.xlsx"))
        ttk.Entry(analysis_frame, textvariable=self.output_excel_var, width=50).grid(row=1, column=1, padx=5, pady=5)
        ttk.Button(analysis_frame, text="浏览", command=lambda: self.select_save_file(self.output_excel_var)).grid(row=1, column=2, pady=5)
        
        # 运行按钮
        ttk.Button(analysis_frame, text="开始称呼汇总分析", command=self.run_analysis, style="Accent.TButton").grid(row=2, column=0, columnspan=3, pady=10)
        
        # 分割线
        ttk.Separator(parent, orient=tk.HORIZONTAL).pack(fill=tk.X, padx=10, pady=10)
        
        # 画图功能区
        plot_frame = ttk.LabelFrame(parent, text="趋势图生成", padding=10)
        plot_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # 路径选择
        ttk.Label(plot_frame, text="Excel文件路径：").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.plot_excel_var = tk.StringVar()
        ttk.Entry(plot_frame, textvariable=self.plot_excel_var, width=50).grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(plot_frame, text="浏览", command=lambda: self.select_file(self.plot_excel_var)).grid(row=0, column=2, pady=5)
        
        ttk.Label(plot_frame, text="图片保存文件夹：").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.plot_folder_var = tk.StringVar()
        self.plot_folder_var.set(os.path.join(os.getcwd(), "称呼趋势图"))
        ttk.Entry(plot_frame, textvariable=self.plot_folder_var, width=50).grid(row=1, column=1, padx=5, pady=5)
        ttk.Button(plot_frame, text="浏览", command=lambda: self.select_folder(self.plot_folder_var)).grid(row=1, column=2, pady=5)
        
        # 角色和称呼选择
        ttk.Label(plot_frame, text="称呼人（谁喊）：").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.speaker_var = tk.StringVar()
        ttk.Combobox(plot_frame, textvariable=self.speaker_var, values=self.current_roles, width=20).grid(row=2, column=1, sticky=tk.W, padx=5, pady=5)
        
        ttk.Label(plot_frame, text="被称呼人（喊谁）：").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.target_var = tk.StringVar()
        ttk.Combobox(plot_frame, textvariable=self.target_var, values=self.current_roles, width=20).grid(row=3, column=1, sticky=tk.W, padx=5, pady=5)
        
        ttk.Label(plot_frame, text="称呼（多个用、分隔）：").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.nicknames_var = tk.StringVar()
        ttk.Entry(plot_frame, textvariable=self.nicknames_var, width=50).grid(row=4, column=1, padx=5, pady=5)
        
        # 生成按钮
        ttk.Button(plot_frame, text="生成趋势图", command=self.generate_plot, style="Accent.TButton").grid(row=5, column=0, columnspan=3, pady=10)

    def create_config_panel(self, parent):
        """创建参数配置面板"""
        # 标题
        title_label = ttk.Label(parent, text="参数配置", font=("黑体", 14))
        title_label.pack(pady=10)
        
        # 角色配置区
        role_frame = ttk.LabelFrame(parent, text="角色列表", padding=10)
        role_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(role_frame, text="角色（每行一个）：").pack(anchor=tk.W)
        self.role_text = scrolledtext.ScrolledText(role_frame, height=6, width=60)
        self.role_text.pack(fill=tk.X, pady=5)
        self.role_text.insert(tk.END, "\n".join(self.current_roles))
        
        # 剧集配置区
        drama_frame = ttk.LabelFrame(parent, text="剧集顺序", padding=10)
        drama_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(drama_frame, text="剧集（每行一个，按顺序）：").pack(anchor=tk.W)
        self.drama_text = scrolledtext.ScrolledText(drama_frame, height=6, width=60)
        self.drama_text.pack(fill=tk.X, pady=5)
        self.drama_text.insert(tk.END, "\n".join(self.current_drama_order))
        
        # 称呼配置区
        nick_frame = ttk.LabelFrame(parent, text="预设称呼", padding=10)
        nick_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        ttk.Label(nick_frame, text="称呼配置（格式：角色名|称呼1、称呼2、称呼3）：").pack(anchor=tk.W)
        self.nick_text = scrolledtext.ScrolledText(nick_frame, height=10, width=80)
        self.nick_text.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # 填充默认称呼配置
        nick_config_text = []
        for role, nicks in self.current_preset_nicknames.items():
            nick_config_text.append(f"{role}|{'、'.join(nicks)}")
        self.nick_text.insert(tk.END, "\n".join(nick_config_text))
        
        # 保存配置按钮
        ttk.Button(parent, text="保存配置", command=self.save_config, style="Accent.TButton").pack(pady=10)

    def create_log_panel(self, parent):
        """创建日志面板"""
        # 标题
        title_label = ttk.Label(parent, text="运行日志", font=("黑体", 14))
        title_label.pack(pady=10)
        
        # 日志文本框
        self.log_text = scrolledtext.ScrolledText(parent, height=20, width=80)
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        self.log_text.insert(tk.END, "欢迎使用MANTA称呼分析工具！\n")
        self.log_text.config(state=tk.DISABLED)

    def select_folder(self, var):
        """选择文件夹"""
        folder = filedialog.askdirectory(title="选择文件夹")
        if folder:
            var.set(folder)

    def select_file(self, var):
        """选择文件"""
        file = filedialog.askopenfilename(title="选择文件", filetypes=[("Excel文件", "*.xlsx"), ("所有文件", "*.*")])
        if file:
            var.set(file)

    def select_save_file(self, var):
        """选择保存文件"""
        file = filedialog.asksaveasfilename(title="保存Excel文件", defaultextension=".xlsx", 
                                          filetypes=[("Excel文件", "*.xlsx"), ("所有文件", "*.*")])
        if file:
            var.set(file)

    def log_message(self, msg):
        """添加日志消息"""
        self.log_text.config(state=tk.NORMAL)
        self.log_text.insert(tk.END, f"{msg}\n")
        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)
        self.root.update_idletasks()

    def save_config(self):
        """保存配置"""
        try:
            # 读取角色
            role_text = self.role_text.get("1.0", tk.END).strip()
            self.current_roles = [line.strip() for line in role_text.split("\n") if line.strip()]
            
            # 读取剧集
            drama_text = self.drama_text.get("1.0", tk.END).strip()
            self.current_drama_order = [line.strip() for line in drama_text.split("\n") if line.strip()]
            
            # 读取称呼配置
            nick_text = self.nick_text.get("1.0", tk.END).strip()
            new_nicknames = {}
            for line in nick_text.split("\n"):
                line = line.strip()
                if not line or "|" not in line:
                    continue
                role_part, nick_part = line.split("|", 1)
                role = role_part.strip()
                nicks = [n.strip() for n in nick_part.split("、") if n.strip()]
                if role and nicks:
                    new_nicknames[role] = nicks
            self.current_preset_nicknames = new_nicknames
            
            # 更新下拉框选项
            for combobox in [self.speaker_var, self.target_var]:
                combobox.set("")
                combobox.widget.configure(values=self.current_roles)
            
            self.log_message("配置保存成功！")
            messagebox.showinfo("成功", "配置已保存！")
        except Exception as e:
            self.log_message(f"保存配置失败：{str(e)}")
            messagebox.showerror("错误", f"保存配置失败：{str(e)}")

    def run_analysis(self):
        """运行称呼汇总分析"""
        # 检查路径
        root_folder = self.root_folder_var.get().strip()
        output_excel = self.output_excel_var.get().strip()
        
        if not root_folder or not os.path.exists(root_folder):
            messagebox.showerror("错误", "请选择有效的根文件夹！")
            return
        
        if not output_excel:
            messagebox.showerror("错误", "请选择输出Excel文件路径！")
            return
        
        # 清空日志
        self.log_text.config(state=tk.NORMAL)
        self.log_text.delete("1.0", tk.END)
        self.log_text.config(state=tk.DISABLED)
        
        # 创建分析器
        analyzer = NicknameAnalyzer(
            root_folder=root_folder,
            output_excel=output_excel,
            roles=self.current_roles,
            drama_order=self.current_drama_order,
            preset_nicknames=self.current_preset_nicknames
        )
        
        # 执行分析
        self.log_message("开始执行称呼汇总分析...")
        self.root.update()
        
        # 在新线程中运行（避免界面卡死）
        import threading
        def analysis_thread():
            success = analyzer.run_analysis(self.log_message)
            if success:
                self.root.after(0, lambda: messagebox.showinfo("成功", "称呼汇总分析完成！"))
            else:
                self.root.after(0, lambda: messagebox.showerror("失败", "称呼汇总分析失败，请查看日志！"))
        
        threading.Thread(target=analysis_thread, daemon=True).start()

    def generate_plot(self):
        """生成趋势图"""
        # 检查输入
        excel_path = self.plot_excel_var.get().strip()
        plot_folder = self.plot_folder_var.get().strip()
        speaker = self.speaker_var.get().strip()
        target = self.target_var.get().strip()
        nicknames_input = self.nicknames_var.get().strip()
        
        if not excel_path or not os.path.exists(excel_path):
            messagebox.showerror("错误", "请选择有效的Excel文件！")
            return
        
        if not plot_folder:
            messagebox.showerror("错误", "请选择图片保存文件夹！")
            return
        
        if not speaker:
            messagebox.showerror("错误", "请选择称呼人！")
            return
        
        if not target:
            messagebox.showerror("错误", "请选择被称呼人！")
            return
        
        if not nicknames_input:
            messagebox.showerror("错误", "请输入要分析的称呼！")
            return
        
        # 解析称呼列表
        nicknames = [n.strip() for n in nicknames_input.split("、") if n.strip()]
        if not nicknames:
            messagebox.showerror("错误", "请输入有效的称呼！")
            return
        
        # 创建绘图器
        plotter = PlotGenerator(
            excel_path=excel_path,
            plot_folder=plot_folder,
            drama_order=self.current_drama_order
        )
        
        # 执行绘图
        self.log_message(f"开始生成趋势图：{speaker} → {target} - {nicknames}")
        self.root.update()
        
        # 在新线程中运行
        import threading
        def plot_thread():
            # 加载数据
            if not plotter.load_trend_data(self.log_message):
                self.root.after(0, lambda: messagebox.showerror("失败", "加载趋势数据失败！"))
                return
            
            # 生成图表
            success = plotter.generate_plot(speaker, target, nicknames, self.log_message)
            if success:
                self.root.after(0, lambda: messagebox.showinfo("成功", "趋势图生成完成！"))
            else:
                self.root.after(0, lambda: messagebox.showerror("失败", "趋势图生成失败，请查看日志！"))
        
        threading.Thread(target=plot_thread, daemon=True).start()

# ===================== 【主程序入口】 =====================
if __name__ == "__main__":
    # 设置tkinter样式
    root = tk.Tk()
    style = ttk.Style(root)
    style.configure("Accent.TButton", font=("黑体", 10))
    
    # 创建并运行应用
    app = MainApplication(root)
    root.mainloop()