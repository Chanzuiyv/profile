import pandas as pd
import matplotlib.pyplot as plt
import os

# ===================== 【配置：直接读取你的Excel】 =====================
EXCEL_PATH = r"C:\Users\ThinkPad\Desktop\杂\逐声计划\团综文字整理\字幕整理\合并结果\MANTA全剧称呼分析结果.xlsx"
PLOT_FOLDER = r"C:\Users\ThinkPad\Desktop\杂\逐声计划\团综文字整理\字幕整理\合并结果\称呼趋势图"
os.makedirs(PLOT_FOLDER, exist_ok=True)

# 时间线顺序（必须和之前一致）
DRAMA_ORDER = [
    "LASER出道日", "险象环声", "WE FOUR", "FINE DAY",
    "一起再出发", "名利场", "NEW DAYS"
]

# 安全文件名（防报错）
def safe_filename(name):
    invalid = ['<','>',':','"','/','\\','|','?','*','!','@','#','$','%','^','&','~']
    for c in invalid:
        name = name.replace(c, '')
    return name.strip()

# ===================== 【核心：从Excel读趋势数据】 =====================
def load_trend_from_excel():
    print("📊 正在从 Excel 读取趋势数据...")
    df = pd.read_excel(EXCEL_PATH, sheet_name="7_称呼时间趋势")
    print("✅ 读取完成！可以开始画图啦")
    return df

# ===================== 【画单张图】 =====================
def draw_one_plot(df):
    print("\n" + "="*50)
    print("🎨 独立画图工具（输入 q 退出）")
    print("="*50)

    # 输入称呼人
    speaker = input("👉 称呼人（谁喊）：").strip()
    if speaker.lower() == "q":
        return False

    # 输入被称呼人
    target = input("👉 被称呼人（喊谁）：").strip()
    if target.lower() == "q":
        return False

    # 输入称呼
    nick_input = input("👉 称呼（多个用、分隔）：").strip()
    if nick_input.lower() == "q":
        return False

    target_nicks = [n.strip() for n in nick_input.split("、") if n.strip()]

    # 筛选数据
    df_filter = df[
        (df["说话人"] == speaker) &
        (df["被称呼人"] == target) &
        (df["称呼"].isin(target_nicks))
    ]

    if df_filter.empty:
        print("⚠️ 没有找到数据，请检查名字是否正确")
        return True

    # Y轴设置：最大值 + 2，全整数
    max_val = df_filter["本季出现次数"].max()
    y_upper = max_val + 2

    # 画图
    plt.rcParams["font.sans-serif"] = ["SimHei"]
    plt.rcParams["axes.unicode_minus"] = False
    fig, ax = plt.subplots(figsize=(10, 5))

    for nick in target_nicks:
        sub = df_filter[df_filter["称呼"] == nick].copy()
        sub["排序"] = sub["季数/时间"].map(DRAMA_ORDER.index)
        sub = sub.sort_values("排序")

        x = sub["排序"].tolist()
        y = sub["本季出现次数"].tolist()
        ax.plot(x, y, marker='o', linewidth=2, label=nick)

    # X轴时间线
    ax.set_xticks(range(len(DRAMA_ORDER)))
    ax.set_xticklabels(DRAMA_ORDER, rotation=25, ha='right')

    # Y轴纯整数 + 上限+2
    ax.set_ylim(0, y_upper)
    ax.yaxis.set_major_locator(plt.MaxNLocator(integer=True))

    ax.set_title(f"{speaker} → {target} 称呼变化趋势", fontsize=14)
    ax.set_ylabel("出现次数")
    ax.legend()
    plt.tight_layout()

    # 保存
    safe_spk = safe_filename(speaker)
    safe_tgt = safe_filename(target)
    fname = f"{safe_spk}→{safe_tgt}_趋势.png"
    save_path = os.path.join(PLOT_FOLDER, fname)
    plt.savefig(save_path, dpi=300)
    plt.close()

    print(f"✅ 保存成功：{save_path}")
    return True

# ===================== 【循环画多张】 =====================
def draw_loop():
    df = load_trend_from_excel()
    while True:
        keep = draw_one_plot(df)
        if not keep:
            print("\n👋 退出画图工具，全部完成！")
            break

# ===================== 【运行】 =====================
if __name__ == "__main__":
    draw_loop()