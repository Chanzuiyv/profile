import os
from utils import remove_punctuation, is_charset_subset, extract_episode_number
from color import GREEN, YELLOW, RED, RESET

def find_matching_pairs(my_root, col_root, episode_map):
    my_files = []
    for root, dirs, files in os.walk(my_root):
        for f in files:
            if f.endswith('.txt'):
                full = os.path.join(root, f)
                rel = os.path.relpath(full, my_root)
                parent_rel = os.path.dirname(rel)
                my_files.append((full, rel, parent_rel, f))

    col_index = {}
    all_col_files = []
    for root, dirs, files in os.walk(col_root):
        for f in files:
            if f.endswith('.txt'):
                full = os.path.join(root, f)
                rel = os.path.relpath(full, col_root)
                parent_rel = os.path.dirname(rel)
                col_index.setdefault(parent_rel, []).append((full, rel, f))
                all_col_files.append((full, rel, f))

    pairs = []
    unmatched = []
    used_col = set()

    for my_full, my_rel, my_parent, my_name in my_files:
        my_name_clean = remove_punctuation(my_name)
        my_ep_num = extract_episode_number(my_name)
        print(f"\n处理你的文件: {my_rel}")
        print(f"  去标点后: {my_name_clean}, 期数: {my_ep_num}")

        best_match = None
        match_method = None

        # 同目录字符集包含
        candidates = col_index.get(my_parent, [])
        for col_full, col_rel, col_name in candidates:
            if col_full in used_col:
                continue
            col_name_clean = remove_punctuation(col_name)
            if is_charset_subset(my_name_clean, col_name_clean):
                best_match = (col_full, col_rel, col_name)
                match_method = "同目录字符集包含"
                break

        # 全局字符集包含
        if not best_match:
            print(f"  {YELLOW}[WARNING] 同目录无匹配，尝试全局字符集包含...{RESET}")
            for col_full, col_rel, col_name in all_col_files:
                if col_full in used_col:
                    continue
                col_name_clean = remove_punctuation(col_name)
                if is_charset_subset(my_name_clean, col_name_clean):
                    best_match = (col_full, col_rel, col_name)
                    match_method = "全局字符集包含"
                    break

        # 按期数匹配
        if not best_match and my_ep_num:
            print(f"  {YELLOW}[WARNING] 字符集匹配失败，尝试按期数 '{my_ep_num}' 匹配...{RESET}")
            for col_full, col_rel, col_name in all_col_files:
                if col_full in used_col:
                    continue
                col_ep_num = extract_episode_number(col_name)
                if col_ep_num == my_ep_num:
                    best_match = (col_full, col_rel, col_name)
                    match_method = f"期数匹配 (第{my_ep_num}期)"
                    break

        if best_match:
            col_full, col_rel, col_name = best_match
            print(f"  {GREEN}✓ 匹配成功 ({match_method}): {col_rel}{RESET}")
            pairs.append((my_full, col_full, my_rel))
            used_col.add(col_full)
        else:
            print(f"  {RED}[ERROR] 未找到任何匹配文件！{RESET}")
            unmatched.append({
                'my_path': my_full,
                'my_rel': my_rel,
                '文件名': my_name,
                '去标点后文件名': my_name_clean,
                '提取的期数': my_ep_num if my_ep_num else '',
                '父目录': my_parent,
                '匹配失败原因': '未找到任何匹配'
            })

    return pairs, unmatched