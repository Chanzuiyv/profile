import re
from config import ENV_PATTERN, MAIN_ROLES

def is_env_line(line: str) -> bool:
    return bool(re.match(ENV_PATTERN, line.strip()))

def is_role_line(line: str, valid_roles: set) -> bool:
    line = line.strip()
    if not line.startswith('【'):
        return False
    match = re.match(r'^【([^】]+)】', line)
    if not match:
        return False
    role = match.group(1)
    if role in valid_roles:
        return True
    for main in MAIN_ROLES:
        if main in role:
            return True
    if role.startswith('小') and role[1:] in MAIN_ROLES:
        return True
    return False

def parse_script(filepath: str, valid_roles: set):
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = [line.rstrip('\n') for line in f]

    paragraphs = []
    i = 0
    while i < len(lines):
        stripped = lines[i].strip()
        if not stripped:
            i += 1
            continue
        if is_env_line(stripped):
            paragraphs.append({'type': 'env', 'content': stripped})
            i += 1
            continue
        if is_role_line(stripped, valid_roles):
            match = re.match(r'^【([^】]+)】', stripped)
            role = match.group(1).strip()
            i += 1
            dialogue_lines = []
            while i < len(lines):
                next_line = lines[i].strip()
                if not next_line:
                    i += 1
                    continue
                if is_env_line(next_line) or is_role_line(next_line, valid_roles):
                    break
                dialogue_lines.append(next_line)
                i += 1
            if dialogue_lines:
                paragraphs.append({'type': 'dialogue', 'role': role, 'lines': dialogue_lines})
            continue
        i += 1
    return paragraphs