import re
import string

def remove_punctuation(text: str) -> str:
    translator = str.maketrans('', '', string.punctuation + '！？｡＂＃＄％＆＇（）＊＋，－／：；＜＝＞＠［＼］＾＿｀｛｜｝～、。·《》【】「」『』〔〕…—～')
    text_no_punct = text.translate(translator)
    return text_no_punct.replace(' ', '').replace('\u3000', '')

def extract_episode_number(filename: str) -> str:
    match = re.search(r'第([零一二三四五六七八九十百千万\d]+)期', filename)
    if match:
        num_str = match.group(1)
        ch_map = {'零':'0','一':'1','二':'2','三':'3','四':'4','五':'5','六':'6','七':'7','八':'8','九':'9','十':'10'}
        if num_str in ch_map:
            return ch_map[num_str]
        elif '十' in num_str:
            if num_str == '十':
                return '10'
            elif num_str.startswith('十'):
                return '1' + ch_map.get(num_str[1], '0')
            elif num_str.endswith('十'):
                return ch_map.get(num_str[0], '0') + '0'
        return num_str
    return None

def is_charset_subset(short_name: str, long_name: str) -> bool:
    return set(short_name).issubset(set(long_name))