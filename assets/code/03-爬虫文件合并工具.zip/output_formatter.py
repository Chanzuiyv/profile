def format_output(paragraphs, output_path):
    """总是创建输出文件，即使 paragraphs 为空也生成空文件"""
    with open(output_path, 'w', encoding='utf-8') as f:
        for idx, para in enumerate(paragraphs):
            if para['type'] == 'env':
                f.write(para['content'] + '\n')
            else:
                f.write(f"【{para['role']}】\n")
                for line in para['lines']:
                    f.write('    ' + line + '\n')
            if idx != len(paragraphs) - 1:
                f.write('\n')
    return True