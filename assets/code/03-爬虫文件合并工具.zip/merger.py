import difflib

def normalize_paragraph(para):
    if para['type'] == 'env':
        return f"ENV:{para['content']}"
    else:
        return f"DIA:{para['role']}:{'\n'.join(para['lines'])}"

def merge_paragraphs(list1, list2):
    norm1 = [normalize_paragraph(p) for p in list1]
    norm2 = [normalize_paragraph(p) for p in list2]
    matcher = difflib.SequenceMatcher(None, norm1, norm2)
    merged = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == 'equal':
            merged.extend(list1[i1:i2])
        elif tag == 'insert':
            merged.extend(list2[j1:j2])
        elif tag == 'delete':
            merged.extend(list1[i1:i2])
        elif tag == 'replace':
            merged.extend(list2[j1:j2])
    seen = set()
    final = []
    for p in merged:
        key = normalize_paragraph(p)
        if key not in seen:
            final.append(p)
            seen.add(key)
    return final