import os
from config import MY_DIR, COLLEAGUE_DIR, OUTPUT_DIR, EPISODE_INFO_DIR, UNMATCHED_REPORT, MAIN_ROLES, NICKNAMES, FILTER_ROLES
from csv_loader import load_episode_info
from file_matcher import find_matching_pairs
from script_parser import parse_script
from merger import merge_paragraphs
from output_formatter import format_output
from reporter import save_unmatched_report
from color import GREEN, RED, RESET

def get_all_valid_roles(episode_map):
    temp_roles = set()
    for info in episode_map.values():
        temp_roles.update(info['temp_roles'])
    all_roles = MAIN_ROLES.union(NICKNAMES).union(temp_roles) - FILTER_ROLES
    return all_roles

def main():
    print("加载剧集信息...")
    episode_map = load_episode_info(EPISODE_INFO_DIR)
    valid_roles = get_all_valid_roles(episode_map)
    print(f"有效角色数: {len(valid_roles)}")

    print("匹配用户文件与同事文件...")
    pairs, unmatched = find_matching_pairs(MY_DIR, COLLEAGUE_DIR, episode_map)
    print(f"\n{GREEN}成功匹配 {len(pairs)} 对文件{RESET}")
    if unmatched:
        print(f"{RED}未匹配文件数: {len(unmatched)}{RESET}")
        save_unmatched_report(unmatched, UNMATCHED_REPORT)

    # 记录已处理的用户文件路径（避免重复输出）
    processed_my_paths = set()

    # 处理匹配成功的文件对（合并）
    for my_path, col_path, rel_path in pairs:
        out_full = os.path.join(OUTPUT_DIR, rel_path)
        os.makedirs(os.path.dirname(out_full), exist_ok=True)
        my_paras = parse_script(my_path, valid_roles)
        col_paras = parse_script(col_path, valid_roles) if col_path else []
        print(f"合并: {rel_path} (我的{len(my_paras)}段, 同事{len(col_paras)}段)")
        if my_paras and col_paras:
            merged = merge_paragraphs(my_paras, col_paras)
        else:
            merged = my_paras or col_paras
        format_output(merged, out_full)
        print(f"  输出: {out_full} ({len(merged)}段)")
        processed_my_paths.add(my_path)

    # 处理未匹配的用户文件（只输出用户自己的内容）
    for item in unmatched:
        my_path = item['my_path']
        my_rel = item['my_rel']
        if my_path in processed_my_paths:
            continue
        out_full = os.path.join(OUTPUT_DIR, my_rel)
        os.makedirs(os.path.dirname(out_full), exist_ok=True)
        my_paras = parse_script(my_path, valid_roles)
        print(f"未匹配，单独输出用户文件: {my_rel} (我的{len(my_paras)}段)")
        format_output(my_paras, out_full)
        print(f"  输出: {out_full} ({len(my_paras)}段)")

    print("全部完成！")

if __name__ == '__main__':
    main()