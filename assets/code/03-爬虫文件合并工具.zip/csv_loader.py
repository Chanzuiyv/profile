import os
import csv
from utils import remove_punctuation
from color import YELLOW, GREEN, RED, RESET

def load_episode_info(episode_info_dir):
    episode_map = {}
    if not os.path.exists(episode_info_dir):
        print(f"{YELLOW}警告：剧集信息目录不存在 {episode_info_dir}{RESET}")
        return episode_map

    for file in os.listdir(episode_info_dir):
        if not file.endswith('.csv'):
            continue
        filepath = os.path.join(episode_info_dir, file)
        for enc in ['gbk', 'gb18030', 'utf-8-sig', 'utf-8']:
            try:
                with open(filepath, 'r', encoding=enc) as f:
                    reader = csv.DictReader(f)
                    possible_name_cols = ['剧集名', '名称', '标题', 'name', 'title']
                    name_col = None
                    for col in possible_name_cols:
                        if col in reader.fieldnames:
                            name_col = col
                            break
                    if not name_col:
                        print(f"{YELLOW}警告：文件 {file} 无剧集名列，跳过{RESET}")
                        break
                    for row in reader:
                        ep_name = row.get(name_col, '').strip()
                        if not ep_name:
                            continue
                        temp_str = row.get('temporary_chars', '').strip()
                        temp_roles = set()
                        if temp_str:
                            for sep in [' ', '，', ',']:
                                if sep in temp_str:
                                    parts = temp_str.split(sep)
                                    for p in parts:
                                        p = p.strip()
                                        if p:
                                            temp_roles.add(p)
                                    break
                            else:
                                temp_roles.add(temp_str)
                        key = remove_punctuation(ep_name)
                        episode_map[key] = {
                            'original_name': ep_name,
                            'temp_roles': temp_roles
                        }
                print(f"{GREEN}成功加载 {file}，编码 {enc}{RESET}")
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        else:
            print(f"{RED}错误：无法读取 {file}{RESET}")
    return episode_map