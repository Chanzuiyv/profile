import csv
from color import YELLOW, GREEN, RESET

def save_unmatched_report(unmatched, report_path):
    if not unmatched:
        print(f"{GREEN}所有文件均匹配成功，无需生成未匹配报告。{RESET}")
        return
    # 定义CSV列名，包含所有可能的键
    fieldnames = ['my_path', 'my_rel', '文件名', '去标点后文件名', '提取的期数', '父目录', '匹配失败原因']
    with open(report_path, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        # 确保每个字典都有所有字段，缺失的填空字符串
        for row in unmatched:
            clean_row = {k: row.get(k, '') for k in fieldnames}
            writer.writerow(clean_row)
    print(f"{YELLOW}未匹配文件统计已保存至: {report_path}{RESET}")