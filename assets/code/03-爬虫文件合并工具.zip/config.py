import os

MY_DIR = r"C:\Users\ThinkPad\Desktop\杂\逐声计划\团综文字整理\规范剧本_最终版"
COLLEAGUE_DIR = r"C:\Users\ThinkPad\Desktop\杂\逐声计划\团综文字整理\字幕整理\已格式化_云攸爬虫"
OUTPUT_DIR = r"C:\Users\ThinkPad\Desktop\杂\逐声计划\团综文字整理\合并结果"
EPISODE_INFO_DIR = r"C:\Users\ThinkPad\Desktop\杂\逐声计划\团综文字整理\代码\自动获取弹幕\剧集信息"
UNMATCHED_REPORT = r"C:\Users\ThinkPad\Desktop\杂\逐声计划\团综文字整理\未匹配文件统计.csv"

MAIN_ROLES = {"顾子尧", "夏予扬", "乔殊", "林致", "柏闻", "季少一", "江恪", "许向安", "许向宁"}
NICKNAMES = {"季少", "殊殊子", "吱吱", "顾饺", "宁宁", "安安", "柏队", "克制哥"}
FILTER_ROLES = {"报幕", "MANTA", "LASER"}

ENV_PATTERN = r'^[（(]'