import pandas as pd

df = pd.read_excel('c:/Users/ThinkPad/Desktop/逐声计划123/任务管理表/技术组网页/四月/四月第一周.xlsx')
print('总表完整数据(前10行):')
for row_idx in range(min(10, len(df))):
    print(f'\n行{row_idx}:')
    for col_idx in range(len(df.columns)):
        val = df.iloc[row_idx, col_idx]
        print(f'  列{col_idx}: {val}')
