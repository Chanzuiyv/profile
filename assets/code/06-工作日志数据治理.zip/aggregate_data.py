import os
import re
import openpyxl


class TaskAggregator:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.personnel = self._load_personnel()

    def _load_personnel(self):
        personnel_file = os.path.join(self.base_dir, "人员表.txt")
        personnel = {}
        current_group = None

        with open(personnel_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue

                if line.endswith("：") or line.endswith(":"):
                    current_group = line[:-1]
                    personnel[current_group] = []
                elif current_group:
                    members = [m.strip() for m in line.split("、") if m.strip()]
                    personnel[current_group].extend(members)

        return personnel

    def _format_date(self, date_value):
        if date_value is None:
            return ""

        date_str = str(date_value)

        if "YYYY/MM/DD" in date_str:
            return ""

        match = re.search(r"(\d{4})[-/年](\d{1,2})[-/月](\d{1,2})", date_str)
        if match:
            return f"{match.group(1)}/{match.group(2).zfill(2)}/{match.group(3).zfill(2)}"

        match = re.search(r"(\d{4})(\d{2})(\d{2})", date_str)
        if match:
            return f"{match.group(1)}/{match.group(2)}/{match.group(3)}"

        return date_str

    def _find_non_current_group(self, source_data, current_group):
        source_group = str(source_data[4]).strip() if source_data[4] else ""
        target_group = str(source_data[5]).strip() if source_data[5] else ""

        if source_group and source_group != current_group:
            return source_group
        elif target_group and target_group != current_group:
            return target_group

        return ""

    def _match_owner(self, source_data, current_group):
        sender = str(source_data[2]).strip() if source_data[2] else ""
        receiver = str(source_data[3]).strip() if source_data[3] else ""

        current_members = self.personnel.get(current_group, [])
        matched = []

        for member in current_members:
            if member in sender or member in receiver:
                matched.append(member)

        return "、".join(matched) if matched else ""

    def _build_description(self, source_data):
        content = str(source_data[6]).strip() if source_data[6] else ""
        remark = str(source_data[9]).strip() if source_data[9] else ""

        if remark and remark != "-":
            return f"{content} {remark}"
        return content

    def _find_start_row(self, target_ws):
        for row in range(2, target_ws.max_row + 1):
            cell_value = str(target_ws.cell(row=row, column=2).value)
            if cell_value == "YYYY/MM/DD":
                return row

        return target_ws.max_row + 1

    def _is_empty_row(self, source_ws, row):
        for col in range(1, 11):
            if source_ws.cell(row=row, column=col).value is not None:
                return False
        return True

    def process_file(self, source_path, target_path, current_group):
        source_wb = openpyxl.load_workbook(source_path)
        source_ws = source_wb.active

        target_wb = openpyxl.load_workbook(target_path)
        target_ws = target_wb.active

        start_row = self._find_start_row(target_ws)
        output_row = start_row

        for row in range(2, source_ws.max_row + 1):
            if self._is_empty_row(source_ws, row):
                continue

            source_data = []
            for col in range(1, 11):
                source_data.append(source_ws.cell(row=row, column=col).value)

            target_data = [""] * 17

            target_data[0] = target_ws.cell(row=output_row, column=1).value
            target_data[1] = self._format_date(source_data[0])
            target_data[2] = source_data[6]
            target_data[4] = self._find_non_current_group(source_data, current_group)
            target_data[5] = "跨组需求"
            target_data[6] = "已完成"
            target_data[7] = "P1"
            target_data[8] = self._match_owner(source_data, current_group)
            target_data[10] = target_data[4]
            target_data[14] = source_data[7]
            target_data[16] = self._build_description(source_data)

            for col in range(1, 18):
                target_ws.cell(row=output_row, column=col, value=target_data[col - 1])

            output_row += 1

        target_wb.save(target_path)
        print(f"处理完成: {target_path}")

    def run(self):
        groups = ["内容组", "美工组", "技术组网页", "技术组自动化", "运营组", "审核组", "策划"]
        months = ["四月", "五月", "六月"]

        for group in groups:
            for month in months:
                source_dir = os.path.join(self.base_dir, "源数据", group, month)
                target_dir = os.path.join(self.base_dir, "任务管理表", group, month)

                if not os.path.exists(source_dir):
                    continue

                if not os.path.exists(target_dir):
                    continue

                for filename in os.listdir(source_dir):
                    if not filename.lower().endswith(".xlsx"):
                        continue

                    source_path = os.path.join(source_dir, filename)
                    
                    name_without_ext = os.path.splitext(filename)[0].replace(" ", "")
                    target_path = None
                    
                    for target_file in os.listdir(target_dir):
                        if target_file.lower().endswith(".xlsx"):
                            target_name = os.path.splitext(target_file)[0].replace(" ", "")
                            if target_name == name_without_ext:
                                target_path = os.path.join(target_dir, target_file)
                                break

                    if target_path:
                        self.process_file(source_path, target_path, group)
                    else:
                        print(f"警告: 目标文件不存在 - {os.path.join(target_dir, filename)}")


if __name__ == "__main__":
    base_directory = r"c:\Users\ThinkPad\Desktop\逐声计划123"
    aggregator = TaskAggregator(base_directory)
    aggregator.run()