import pandas as pd
import os
import re

group_members = {}
with open('人员表.txt', 'r', encoding='utf-8') as f:
    current_group = ''
    for line in f:
        line = line.strip()
        if '：' in line or ':' in line:
            if '：' in line:
                current_group = line.split('：')[0]
            else:
                current_group = line.split(':')[0]
        elif line and current_group:
            members = [m.strip() for m in line.split('、') if m.strip()]
            group_members[current_group] = members

groups = ['内容组', '审核组', '技术组网页', '技术组自动化', '运营组', '美工组', '策划']
months = ['四月', '五月', '六月']
weeks = {
    '四月': ['第一周', '第二周', '第三周', '第四周'],
    '五月': ['第一周', '第二周', '第三周', '第四周'],
    '六月': ['第一周', '第二周', '第三周', '第四周']
}

def find_source_file(group, month, week):
    filename = f'{month}{week}.xlsx'
    folder_path = f'源数据/{group}/{month}'
    if not os.path.exists(folder_path):
        return None
    for f in os.listdir(folder_path):
        if f.replace(' ', '') == filename:
            return os.path.join(folder_path, f)
    return None

def find_write_start_row(df):
    for row_idx in range(len(df)):
        date_val = df.iloc[row_idx, 1] if len(df.columns) > 1 else ''
        if str(date_val).strip() == 'YYYY/MM/DD':
            return row_idx
    return None

def find_group_member(group, sender, receiver):
    members = group_members.get(group, [])
    sender_str = str(sender).strip()
    receiver_str = str(receiver).strip()
    
    for member in members:
        if member in sender_str:
            return member
        if member in receiver_str:
            return member
    
    return ''

def format_date(date_val):
    if pd.isna(date_val):
        return ''
    if isinstance(date_val, pd.Timestamp):
        return date_val.strftime('%Y/%m/%d')
    return str(date_val).strip()

def format_deadline(deadline):
    if pd.isna(deadline):
        return ''
    return str(deadline).strip()

for group in groups:
    for month in months:
        for week in weeks[month]:
            source_file = find_source_file(group, month, week)
            if not source_file:
                continue
            
            target_file = f'任务管理表/{group}/{month}/{month}{week}.xlsx'
            if not os.path.exists(target_file):
                continue
            
            try:
                source_df = pd.read_excel(source_file)
                target_df = pd.read_excel(target_file, header=None)
                
                start_row = find_write_start_row(target_df)
                if start_row is None:
                    print(f'跳过 {group}/{month}/{week}: 未找到YYYY/MM/DD标记行')
                    continue
                
                insert_row = start_row
                data_rows = len(source_df)
                
                for i in range(data_rows):
                    if insert_row + i >= len(target_df):
                        new_row = [pd.NA] * len(target_df.columns)
                        target_df.loc[insert_row + i] = new_row
                    
                    row = source_df.iloc[i]
                    
                    target_df.iloc[insert_row + i, 1] = format_date(row['交接日期'])
                    target_df.iloc[insert_row + i, 2] = str(row['事项内容']).strip() if not pd.isna(row['事项内容']) else ''
                    target_df.iloc[insert_row + i, 5] = '跨组需求'
                    target_df.iloc[insert_row + i, 6] = '已完成'
                    target_df.iloc[insert_row + i, 7] = 'P1'
                    
                    sender = row['发送人'] if not pd.isna(row['发送人']) else ''
                    receiver = row['接收方'] if not pd.isna(row['接收方']) else ''
                    target_df.iloc[insert_row + i, 8] = find_group_member(group, sender, receiver)
                    
                    notes = str(row['备注']).strip() if not pd.isna(row['备注']) else ''
                    task_desc = str(row['事项内容']).strip() if not pd.isna(row['事项内容']) else ''
                    if notes and notes != '-':
                        task_desc = f'{task_desc} {notes}'
                    target_df.iloc[insert_row + i, 16] = task_desc
                    
                    target_df.iloc[insert_row + i, 14] = format_deadline(row['截止时间'])
                
                target_df.to_excel(target_file, index=False, header=False)
                print(f'完成: {group}/{month}/{week} (插入{data_rows}行)')
                
            except Exception as e:
                print(f'失败: {group}/{month}/{week} - {e}')

print('\n全部处理完成！')