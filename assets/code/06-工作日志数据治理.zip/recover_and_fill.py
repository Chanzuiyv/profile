import pandas as pd
import os
from openpyxl import load_workbook
import datetime

def load_group_members():
    group_members = {}
    with open('人员表.txt', 'r', encoding='utf-8') as f:
        current_group = ''
        for line in f:
            line = line.strip()
            if not line:
                continue
            if '：' in line:
                group_name = line.split('：')[0]
                current_group = group_name
                group_members[current_group] = []
            else:
                members = [m.strip() for m in line.split('、')]
                if current_group:
                    group_members[current_group].extend(members)
    return group_members

def find_owner(group_members, group_name, sender, receiver):
    members = group_members.get(group_name, [])
    for member in members:
        if member in str(sender) or member in str(receiver):
            return member
    return ''

def format_date(date_value):
    if pd.isna(date_value):
        return ''
    if isinstance(date_value, (pd.Timestamp, datetime.datetime)):
        return date_value.strftime('%Y/%m/%d')
    return str(date_value)

def fill_main_table(group_members):
    main_dir = '任务管理表'
    sub_dir = '源数据'
    
    groups = [g for g in os.listdir(main_dir) if os.path.isdir(os.path.join(main_dir, g))]
    
    for group in groups:
        months = [m for m in os.listdir(os.path.join(main_dir, group)) if os.path.isdir(os.path.join(main_dir, group, m))]
        for month in months:
            weeks = [w for w in os.listdir(os.path.join(main_dir, group, month)) if w.endswith('.xlsx')]
            for week_file in weeks:
                main_path = os.path.join(main_dir, group, month, week_file)
                sub_path = os.path.join(sub_dir, group, month, week_file)
                
                if not os.path.exists(sub_path):
                    sub_path_with_space = os.path.join(sub_dir, group, month, week_file.replace('.xlsx', ' .xlsx'))
                    if os.path.exists(sub_path_with_space):
                        sub_path = sub_path_with_space
                    else:
                        continue
                
                df_main = pd.read_excel(main_path, header=None)
                df_sub = pd.read_excel(sub_path, header=None)
                
                start_row = -1
                for i in range(1, df_main.shape[0]):
                    if str(df_main.iloc[i, 1]) == 'YYYY/MM/DD':
                        start_row = i
                        break
                
                if start_row == -1:
                    continue
                
                data_rows = []
                for i in range(1, df_sub.shape[0]):
                    row_data = {}
                    
                    row_data[1] = format_date(df_sub.iloc[i, 0])
                    row_data[2] = str(df_sub.iloc[i, 6]) if pd.notna(df_sub.iloc[i, 6]) else ''
                    
                    remark = str(df_sub.iloc[i, 9]) if pd.notna(df_sub.iloc[i, 9]) else ''
                    if remark and remark != '-':
                        row_data[16] = str(df_sub.iloc[i, 6]) + ' ' + remark if pd.notna(df_sub.iloc[i, 6]) else remark
                    else:
                        row_data[16] = str(df_sub.iloc[i, 6]) if pd.notna(df_sub.iloc[i, 6]) else ''
                    
                    row_data[14] = str(df_sub.iloc[i, 7]) if pd.notna(df_sub.iloc[i, 7]) else ''
                    
                    row_data[5] = '跨组需求'
                    row_data[6] = '已完成'
                    row_data[7] = 'P1'
                    
                    sender = str(df_sub.iloc[i, 2]) if pd.notna(df_sub.iloc[i, 2]) else ''
                    receiver = str(df_sub.iloc[i, 3]) if pd.notna(df_sub.iloc[i, 3]) else ''
                    row_data[8] = find_owner(group_members, group, sender, receiver)
                    
                    data_rows.append(row_data)
                
                if not data_rows:
                    continue
                
                wb = load_workbook(main_path)
                ws = wb.active
                
                for idx, row_data in enumerate(data_rows):
                    write_row = start_row + idx
                    for col, value in row_data.items():
                        cell = ws.cell(row=write_row + 1, column=col + 1, value=value)
                
                wb.save(main_path)
                print(f'已填充: {group}/{month}/{week_file}')

if __name__ == '__main__':
    group_members = load_group_members()
    fill_main_table(group_members)