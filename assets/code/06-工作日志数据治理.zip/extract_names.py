import pandas as pd
import os

groups = ['内容组', '审核组', '技术组网页', '技术组自动化', '运营组', '美工组', '策划']
months = ['四月', '五月', '六月']

send_names = set()
receive_names = set()

for group in groups:
    for month in months:
        folder_path = os.path.join('.', group, month)
        if not os.path.exists(folder_path):
            continue
        
        for filename in os.listdir(folder_path):
            if not filename.endswith('.xlsx'):
                continue
            
            filepath = os.path.join(folder_path, filename)
            try:
                df = pd.read_excel(filepath)
                
                if '发送人' in df.columns:
                    for name in df['发送人'].dropna().unique():
                        if str(name).strip() != '-' and str(name).strip() != '':
                            send_names.add(str(name).strip())
                
                if '接收方' in df.columns:
                    for name in df['接收方'].dropna().unique():
                        if str(name).strip() != '-' and str(name).strip() != '':
                            receive_names.add(str(name).strip())
                            
            except Exception as e:
                print(f'读取失败: {filepath} - {e}')

all_names = sorted(send_names | receive_names)

result_df = pd.DataFrame({
    '名字': all_names,
    'CN': ''
})

output_file = '人名对照表.xlsx'
result_df.to_excel(output_file, index=False)
print(f'已生成 {output_file}，共 {len(all_names)} 条记录')