import pandas as pd
import os

mapping_df = pd.read_excel('人名对照表.xlsx')
name_to_cn = {}
for _, row in mapping_df.iterrows():
    name = str(row['名字']).strip()
    cn = str(row['CN']).strip()
    if name and cn and cn != 'nan':
        name_to_cn[name] = cn

print(f'加载了 {len(name_to_cn)} 个名字映射')

groups = ['内容组', '审核组', '技术组网页', '技术组自动化', '运营组', '美工组', '策划']
months = ['四月', '五月', '六月']

updated_count = 0

def replace_name(value):
    if pd.isna(value):
        return value
    value_str = str(value).strip()
    if value_str == '-' or value_str == '':
        return value_str
    
    for name, cn in sorted(name_to_cn.items(), key=lambda x: -len(x[0])):
        if name in value_str:
            value_str = value_str.replace(name, cn)
    
    return value_str

for group in groups:
    for month in months:
        folder_path = os.path.join('.', group, month)
        if not os.path.exists(folder_path):
            continue
        
        for filename in os.listdir(folder_path):
            if not filename.endswith('.xlsx'):
                continue
            
            filepath = os.path.join(folder_path, filename)
            try:
                df = pd.read_excel(filepath)
                
                if '发送人' in df.columns:
                    df['发送人'] = df['发送人'].apply(replace_name)
                
                if '接收方' in df.columns:
                    df['接收方'] = df['接收方'].apply(replace_name)
                
                df.to_excel(filepath, index=False)
                updated_count += 1
                print(f'更新: {group}/{month}/{filename}')
                
            except Exception as e:
                print(f'更新失败: {filepath} - {e}')

print(f'\n共更新 {updated_count} 个文件')