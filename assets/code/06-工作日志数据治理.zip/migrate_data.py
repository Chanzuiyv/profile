import pandas as pd
import os

root_files = [
    '四月第一周.xlsx',
    '四月第二周.xlsx',
    '四月第三周.xlsx',
    '四月第四周.xlsx',
    '五月第一周.xlsx',
    '五月第二周.xlsx',
    '五月第三周.xlsx',
    '五月第四周.xlsx',
    '六月第一周.xlsx',
    '六月第二周.xlsx'
]

groups = ['内容组', '审核组', '技术组网页', '技术组自动化', '运营组', '美工组', '策划']

def find_matching_file(folder_path, target_name):
    if not os.path.exists(folder_path):
        return None
    target_name_clean = target_name.replace(' ', '')
    for filename in os.listdir(folder_path):
        if filename.replace(' ', '') == target_name_clean:
            return os.path.join(folder_path, filename)
    return None

for root_file in root_files:
    root_path = os.path.join('.', root_file)
    if not os.path.exists(root_path):
        print(f'跳过不存在的文件: {root_file}')
        continue
    
    print(f'\n处理文件: {root_file}')
    
    xls = pd.ExcelFile(root_path)
    sheets = xls.sheet_names
    
    for sheet in sheets:
        if sheet == '异常数据':
            continue
        
        try:
            df = pd.read_excel(root_path, sheet_name=sheet)
            
            month = root_file[:2]
            
            folder_path = os.path.join('.', sheet, month)
            output_path = find_matching_file(folder_path, root_file)
            
            if output_path:
                df.to_excel(output_path, index=False, header=True)
                print(f'  更新: {output_path} ({len(df)}行)')
            else:
                print(f'  跳过不存在的目标文件: {sheet}/{month}/{root_file}')
                
        except Exception as e:
            print(f'  处理失败 {sheet}: {e}')

print('\n数据迁移完成！')