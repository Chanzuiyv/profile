import pandas as pd

df = pd.read_excel('c:/Users/ThinkPad/Desktop/逐声计划123/任务管理表/技术组网页/四月/四月第一周.xlsx', header=2)
print('总表列名(表头在第3行):')
for i, col in enumerate(df.columns.tolist()):
    print(f'  列{i}: {col}')
print('\n总表前5行数据:')
print(df.head(5))
