import os
from openpyxl import load_workbook

def clean_duplicates():
    main_dir = '任务管理表'
    
    groups = [g for g in os.listdir(main_dir) if os.path.isdir(os.path.join(main_dir, g))]
    
    for group in groups:
        months = [m for m in os.listdir(os.path.join(main_dir, group)) if os.path.isdir(os.path.join(main_dir, group, m))]
        for month in months:
            weeks = [w for w in os.listdir(os.path.join(main_dir, group, month)) if w.endswith('.xlsx')]
            for week_file in weeks:
                main_path = os.path.join(main_dir, group, month, week_file)
                
                wb = load_workbook(main_path)
                ws = wb.active
                
                rows_to_clear = []
                
                for row in range(2, ws.max_row + 1):
                    date_cell = ws.cell(row=row, column=2).value
                    if date_cell and isinstance(date_cell, str) and '00:00:00' in date_cell:
                        rows_to_clear.append(row)
                
                if rows_to_clear:
                    for row in rows_to_clear:
                        for col in range(1, 18):
                            ws.cell(row=row, column=col).value = None
                    
                    wb.save(main_path)
                    print(f'已清理 {len(rows_to_clear)} 行重复数据: {group}/{month}/{week_file}')

if __name__ == '__main__':
    clean_duplicates()