import pandas as pd
import os

target_name = 'I need'

groups = ['内容组', '审核组', '技术组网页', '技术组自动化', '运营组', '美工组', '策划']
months = ['四月', '五月', '六月']

found_records = []

for group in groups:
    for month in months:
        folder_path = os.path.join('.', group, month)
        if not os.path.exists(folder_path):
            continue
        
        for filename in os.listdir(folder_path):
            if not filename.endswith('.xlsx'):
                continue
            
            filepath = os.path.join(folder_path, filename)
            try:
                df = pd.read_excel(filepath)
                
                mask_send = df['发送人'].astype(str).str.strip().str.contains(target_name, case=False, na=False)
                mask_receive = df['接收方'].astype(str).str.strip().str.contains(target_name, case=False, na=False)
                
                if mask_send.any() or mask_receive.any():
                    results = df[mask_send | mask_receive].copy()
                    results['来源文件'] = f'{group}/{month}/{filename}'
                    found_records.append(results)
                    
            except Exception as e:
                print(f'读取失败: {filepath} - {e}')

if found_records:
    all_results = pd.concat(found_records, ignore_index=True)
    print(f'找到 {len(all_results)} 条包含 "{target_name}" 的记录:\n')
    pd.set_option('display.max_columns', None)
    pd.set_option('display.max_rows', None)
    pd.set_option('display.width', 200)
    pd.set_option('display.max_colwidth', 50)
    print(all_results)
else:
    print(f'未找到包含 "{target_name}" 的记录')