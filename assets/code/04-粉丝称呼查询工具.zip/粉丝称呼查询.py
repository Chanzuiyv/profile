import os
from openpyxl import Workbook

# ===================== 你可以直接用的配置 =====================
ROOT_FOLDER = r"C:\Users\ThinkPad\Desktop\杂\逐声计划\团综文字整理\字幕整理\合并结果"
TARGET_ROLES = {
    "顾子尧", "林致", "乔殊", "夏予扬",
    "许向安", "许向宁", "柏闻", "江恪", "季少一",
    "LASER", "MANTA"
}
KEYWORD1 = "她们"
KEYWORD2 = "他们"
# ==============================================================

def parse_txt(file_path):
    """
    解析单个txt文件，提取【角色】+ 台词
    返回：匹配到的条目列表 [(角色, 台词, 文件路径, 文件名), ...]
    """
    results = []
    current_role = None
    current_lines = []

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception:
        try:
            with open(file_path, "r", encoding="gbk") as f:
                lines = f.readlines()
        except:
            print(f"⚠️  编码无法读取：{file_path}")
            return []

    for line in lines:
        line = line.strip()
        if not line:
            continue

        # 判断是否是角色行：【xxx】
        if line.startswith("【") and line.endswith("】"):
            # 先把上一个角色的台词处理完
            if current_role and current_lines:
                dialogue = "\n".join(current_lines).strip()
                if KEYWORD1 in dialogue or KEYWORD2 in dialogue:
                    filename = os.path.basename(file_path)
                    results.append((current_role, dialogue, file_path, filename))

            # 提取新角色
            role = line[1:-1].strip()
            if role in TARGET_ROLES:
                current_role = role
                current_lines = []
            else:
                current_role = None
                current_lines = []

        else:
            # 台词行
            if current_role is not None:
                current_lines.append(line)

    # 处理文件最后一段台词
    if current_role and current_lines:
        dialogue = "\n".join(current_lines).strip()
        if KEYWORD1 in dialogue or KEYWORD2 in dialogue:
            filename = os.path.basename(file_path)
            results.append((current_role, dialogue, file_path, filename))

    return results

def save_to_excel(data_list, keyword, save_path):
    """
    保存到 Excel：角色 | 台词 | 集数(文件名) | 完整路径
    """
    wb = Workbook()
    ws = wb.active
    ws.title = f"含「{keyword}」统计"

    headers = ["角色", f"包含「{keyword}」台词", "集数（文件名）", "文件完整路径"]
    ws.append(headers)

    for item in data_list:
        role, dialogue, full_path, filename = item
        ws.append([role, dialogue, filename, full_path])

    wb.save(save_path)
    print(f"✅ 已生成：{save_path}")

def main():
    all_items = []
    print("🔍 开始扫描所有字幕文件...\n")

    # 遍历所有 txt
    for dirpath, _, filenames in os.walk(ROOT_FOLDER):
        for filename in filenames:
            if filename.lower().endswith(".txt"):
                full_path = os.path.join(dirpath, filename)
                items = parse_txt(full_path)
                all_items.extend(items)

    # 拆分关键词
    tamen1_items = [it for it in all_items if KEYWORD1 in it[1]]
    tamen2_items = [it for it in all_items if KEYWORD2 in it[1]]

    # 保存到桌面（方便找）
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    save_to_excel(tamen1_items, KEYWORD1, os.path.join(desktop, "逐声计划_她们_统计.xlsx"))
    save_to_excel(tamen2_items, KEYWORD2, os.path.join(desktop, "逐声计划_他们_统计.xlsx"))

    print(f"\n🎉 全部完成！")
    print(f"「她们」总计：{len(tamen1_items)} 条")
    print(f"「他们」总计：{len(tamen2_items)} 条")

if __name__ == "__main__":
    main()